﻿Public Class DelEquip
    Private SQL As New SqlControl


    Private Sub DelEquip_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        FetchEquipamentos()

    End Sub


    Private Sub FetchEquipamentos()
        'REFRESH EQUIPMENT LIST
        clbEquip.Items.Clear()

        'ADD PARAMS AND RUN QUERY
        SQL.AddParam("@nu_serie", "%" & txtFilter.Text & "%")

        SQL.ExeQuery("Select Nu_serie FROM Equipamento WHERE Nu_serie LIKE @nu_serie;")

        ' LOOP ROWS AND RETURN EQUIPAMENTOS TO THE LIST
        For Each r As DataRow In SQL.DBT.Rows
            clbEquip.Items.Add(r("Nu_serie"))
        Next
    End Sub


    Private Sub DeleteEquipamento()
        If MsgBox("Os equipamentos selecionados serão removidos! Deseja continuar a operação?", MsgBoxStyle.YesNo, "Remover Equipamento(s) ?") = MsgBoxResult.Yes Then
            'GENERATE MASS DELETE COMMAND
            Dim c As Integer 'unique ID for auto generated numbers
            Dim DelString As String = "" ' query string builder

            For Each i As String In clbEquip.CheckedItems
                SQL.AddParam("@nu_serie" & c, i)
                DelString += "DELETE FROM EQUIPAMENTO WHERE Nu_serie=@nu_serie" & c & ";"
                c += 1
            Next

            SQL.ExeQuery(DelString)

            If SQL.HasException(True) Then Exit Sub

            MsgBox("Os equipamentos selecionados foram removidos!")

            'REFRESH LISTA DE EQUIPAMENTOS

            FetchEquipamentos()

        End If
    End Sub



    Private Sub txtFilter_KeyDown(sender As Object, e As KeyEventArgs) Handles txtFilter.KeyDown
        If e.KeyCode = Keys.Enter Then
            FetchEquipamentos()
            e.Handled() = True
            e.SuppressKeyPress = True  'suppress barulho
        End If
    End Sub

    Private Sub cmdDel_Click(sender As Object, e As EventArgs) Handles cmdDel.Click
        If clbEquip.CheckedItems.Count > 0 Then DeleteEquipamento()
    End Sub

End Class