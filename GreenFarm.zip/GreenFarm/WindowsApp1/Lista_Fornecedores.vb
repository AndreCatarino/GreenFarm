﻿Public Class Lista_Fornecedores

    Public SQL As New SqlControl


    Public Sub LoadGrid(Optional query As String = "")

        If query = "" Then
            SQL.ExeQuery("EXEC getListFornecedores;")

        Else
            SQL.ExeQuery(query)
        End If

        ' ERROR HANDLING
        If SQL.HasException(True) Then Exit Sub

        dgvData.DataSource = SQL.DBT


    End Sub

    Private Sub FindItem()
        SQL.AddParam("@nif", "%" & txtSearch.Text & "%")

        LoadGrid("Select * from Fornecedor where FORNnif like @nif;")


    End Sub



    Private Sub Fornecedores_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'MdiParent = Form2
        LoadGrid()


    End Sub


    Private Sub cmdSearch_Click(sender As Object, e As EventArgs)
        'FindItem()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FindItem()
    End Sub
End Class