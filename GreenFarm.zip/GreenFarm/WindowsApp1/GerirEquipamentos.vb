﻿Public Class GerirEquipamentos

    Public SQL As New SqlControl



    Private Sub Load_cbxFORN()

        ' REFRESH COMBO BOX
        cbxFORN.Items.Clear()

        ' RUN QUERY
        SQL.ExeQuery("EXEC getSerialNUmber;")

        If Sql.HasException(True) Then Exit Sub 'error handling

        '   LOOP ROW AND ADD TO COMBOBOX
        For Each r As DataRow In Sql.DBT.Rows
            cbxFORN.Items.Add(r("Nu_serie").ToString)
        Next


    End Sub

    Private Sub Load_cbxEquipUtil()

        ' REFRESH COMBO BOX
        cbxEquipUtil.Items.Clear()

        ' RUN QUERY
        SQL.ExeQuery("EXEC getSerialNUmber;")

        If SQL.HasException(True) Then Exit Sub 'error handling

        '   LOOP ROW AND ADD TO COMBOBOX
        For Each r As DataRow In SQL.DBT.Rows
            cbxEquipUtil.Items.Add(r("NU_serie").ToString)
        Next

    End Sub

    Private Sub loadGridFORN()

        SQL.ExeQuery("EXEC EquipFornDetails;")

        If SQL.RecordCount < 1 Then Exit Sub

        dgvSupplyDetails.DataSource = SQL.DBT

    End Sub


    Private Sub loadGridEquipUtil()

        SQL.ExeQuery("EXEC EquipUtilizacaoDetails;")

        If SQL.RecordCount < 1 Then Exit Sub

        dgvSupplyDetails.DataSource = SQL.DBT



    End Sub




    Private Sub GerirEquipamentos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Load_cbxFORN()
        Load_cbxEquipUtil()
        loadGridFORN()
        LoadGridUtilizacoesEquip()
    End Sub

    Private Sub cbxFORN_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxFORN.SelectedIndexChanged
        ReloadGridFORNdetails(cbxFORN.Text)
    End Sub

    Private Sub ReloadGridFORNdetails(nuSerie As Integer)

        SQL.AddParam("@nuSerie", nuSerie)
        SQL.ExeQuery("EXEC EquipFornDetailsSearch @NUserie = @nuSerie")

        If SQL.RecordCount < 1 Then
            MsgBox("erro ao procurar supply details desse equipamento")
            Exit Sub
        End If


        dgvSupplyDetails.DataSource = SQL.DBT

    End Sub

    Private Sub ReloadGridUtilizacoes(nuSerie As Integer)

        SQL.AddParam("@nuSerie", nuSerie)
        SQL.ExeQuery("EXEC listEquipUtilSearch @NUserie = @nuSerie")

        If SQL.RecordCount < 1 Then
            MsgBox("Equiamento selecionado não se encontra em utilização")
            Exit Sub
        End If

        dgvEquipUtil.DataSource = SQL.DBT

    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        getEstado.Show()
    End Sub

    Private Sub LoadGridUtilizacoesEquip()

        SQL.ExeQuery("EXEC listEquipUtil;")

        If SQL.RecordCount < 1 Then Exit Sub

        dgvEquipUtil.DataSource = SQL.DBT


    End Sub


    Private Sub cbxEquipUtil_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxEquipUtil.SelectedIndexChanged
        ReloadGridUtilizacoes(cbxEquipUtil.Text)
    End Sub


End Class