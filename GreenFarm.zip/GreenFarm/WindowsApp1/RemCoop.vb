﻿Public Class RemCoop


    Private SQL As New SqlControl

    Private Sub FetchCooperativas()
        'REFRESH EQUIPMENT LIST
        clbCoop.Items.Clear()

        'ADD PARAMS AND RUN QUERY
        SQL.AddParam("@nif", "%" & txtFilter.Text & "%")

        SQL.ExeQuery("Select C_nif FROM Cooperativa WHERE C_nif LIKE @nif;")

        For Each r As DataRow In SQL.DBT.Rows
            clbCoop.Items.Add(r("C_nif"))
        Next

    End Sub

    Private Sub RemoveSupplier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FetchCooperativas()
    End Sub


    Private Sub DeleteCooperativas()
        If MsgBox("As Cooperativas selecionadas serão removidas! Deseja continuar a operação?", MsgBoxStyle.YesNo, "Remover Cooperativa(s) ?") = MsgBoxResult.Yes Then
            'GENERATE MASS DELETE COMMAND
            Dim c As Integer 'unique ID for auto generated numbers
            Dim DelString As String = "" ' query string builder

            For Each i As String In clbCoop.CheckedItems
                SQL.AddParam("@nif" & c, i)
                DelString += "DELETE FROM Cooperativa WHERE C_nif=@nif" & c & ";"
                c += 1
            Next

            SQL.ExeQuery(DelString)

            If SQL.HasException(True) Then Exit Sub

            MsgBox("Os Fornecedores selecionados foram removidos!")

            'REFRESH LISTA DE EQUIPAMENTOS

            FetchCooperativas()

        End If
    End Sub

    Private Sub txtFilter_KeyDown(sender As Object, e As KeyEventArgs) Handles txtFilter.KeyDown
        If e.KeyCode = Keys.Enter Then
            FetchCooperativas()
            e.Handled() = True
            e.SuppressKeyPress = True  'suppress barulho
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If clbCoop.CheckedItems.Count > 0 Then DeleteCooperativas()
    End Sub













End Class