﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UpdateEquip
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtFilter = New System.Windows.Forms.TextBox()
        Me.lbEquipamentos = New System.Windows.Forms.ListBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnALTER = New System.Windows.Forms.Button()
        Me.txtCombustivel = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtMarca = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTipoEquipamento = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSerialNumber = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtFilter
        '
        Me.txtFilter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFilter.Location = New System.Drawing.Point(12, 41)
        Me.txtFilter.Name = "txtFilter"
        Me.txtFilter.Size = New System.Drawing.Size(262, 22)
        Me.txtFilter.TabIndex = 0
        '
        'lbEquipamentos
        '
        Me.lbEquipamentos.FormattingEnabled = True
        Me.lbEquipamentos.ItemHeight = 16
        Me.lbEquipamentos.Location = New System.Drawing.Point(12, 85)
        Me.lbEquipamentos.Name = "lbEquipamentos"
        Me.lbEquipamentos.Size = New System.Drawing.Size(262, 340)
        Me.lbEquipamentos.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnALTER)
        Me.GroupBox1.Controls.Add(Me.txtCombustivel)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtMarca)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtTipoEquipamento)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtSerialNumber)
        Me.GroupBox1.Location = New System.Drawing.Point(306, 85)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(491, 340)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Detalhes do Equipamento"
        '
        'btnALTER
        '
        Me.btnALTER.Location = New System.Drawing.Point(149, 311)
        Me.btnALTER.Name = "btnALTER"
        Me.btnALTER.Size = New System.Drawing.Size(182, 23)
        Me.btnALTER.TabIndex = 8
        Me.btnALTER.Text = "Guardar Alterações"
        Me.btnALTER.UseVisualStyleBackColor = True
        '
        'txtCombustivel
        '
        Me.txtCombustivel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCombustivel.Location = New System.Drawing.Point(163, 198)
        Me.txtCombustivel.Name = "txtCombustivel"
        Me.txtCombustivel.Size = New System.Drawing.Size(145, 22)
        Me.txtCombustivel.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(65, 203)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Combustível :"
        '
        'txtMarca
        '
        Me.txtMarca.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMarca.Location = New System.Drawing.Point(163, 150)
        Me.txtMarca.Name = "txtMarca"
        Me.txtMarca.Size = New System.Drawing.Size(145, 22)
        Me.txtMarca.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(102, 155)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 17)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Marca :"
        '
        'txtTipoEquipamento
        '
        Me.txtTipoEquipamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTipoEquipamento.Location = New System.Drawing.Point(163, 92)
        Me.txtTipoEquipamento.Name = "txtTipoEquipamento"
        Me.txtTipoEquipamento.Size = New System.Drawing.Size(145, 22)
        Me.txtTipoEquipamento.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 94)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(151, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Tipo de Equipamento :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(51, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Serial Number :"
        '
        'txtSerialNumber
        '
        Me.txtSerialNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSerialNumber.Location = New System.Drawing.Point(163, 39)
        Me.txtSerialNumber.Name = "txtSerialNumber"
        Me.txtSerialNumber.ReadOnly = True
        Me.txtSerialNumber.Size = New System.Drawing.Size(145, 22)
        Me.txtSerialNumber.TabIndex = 0
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(261, 17)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Search for Equipments Serial Numbers :"
        '
        'UpdateEquip
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lbEquipamentos)
        Me.Controls.Add(Me.txtFilter)
        Me.Name = "UpdateEquip"
        Me.Text = "Ver Equipamentos"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtFilter As TextBox
    Friend WithEvents lbEquipamentos As ListBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnALTER As Button
    Friend WithEvents txtCombustivel As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtMarca As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtTipoEquipamento As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtSerialNumber As TextBox
    Friend WithEvents Label5 As Label
End Class
