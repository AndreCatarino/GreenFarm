﻿Public Class NewEquipment

    Private SQL As New SqlControl




    Private Sub NewEquipment_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub InsertEquipment()
        'ADD SQL PARAMS AND RUN THE COMMAND 

        SQL.AddParam("@numeroSerie", txtNumeroSerie.Text)
        SQL.AddParam("@tipoEquipamento", txtTipoEquipamento.Text)
        SQL.AddParam("@marca", txtMarca.Text)
        SQL.AddParam("@combustivel", txtCombustivel.Text)


        SQL.ExeQuery("EXEC NewEquip @EquipType=@tipoEquipamento,@COMBUSTIVEL=@combustivel, @NumeroSerie=@numeroSerie,@brand=@marca")


        ' REPORT & ABORT ON ERRORS

        If SQL.HasException(True) Then Exit Sub

        MsgBox("Equipamento adicionado com sucesso !")

        If SQL.DBT.Rows.Count > 0 Then
            Dim r As DataRow = SQL.DBT.Rows(0)
            'MsgBox(r("LastID").ToString)
        End If

        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        InsertEquipment()
    End Sub

    Private Sub txtNumeroSerie_TextChanged(sender As Object, e As EventArgs) Handles txtNumeroSerie.TextChanged, txtTipoEquipamento.TextChanged, txtCombustivel.TextChanged, txtMarca.TextChanged

        'BASIC VALIDATION
        If Not String.IsNullOrWhiteSpace(txtNumeroSerie.Text) AndAlso Not String.IsNullOrWhiteSpace(txtTipoEquipamento.Text) AndAlso Not String.IsNullOrWhiteSpace(txtMarca.Text) AndAlso Not String.IsNullOrWhiteSpace(txtCombustivel.Text) Then
            cmdAdd.Enabled = True
        End If
    End Sub



End Class