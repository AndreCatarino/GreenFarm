﻿Imports System.Data.SqlClient


Public Class Form1


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Login.Click

        Dim connection As New SqlConnection("Data Source = tcp:mednat.ieeta.pt\SQLSERVER,8101;  initial catalog = p7g8; uid = p7g8; password = bd_2019g8")


        Dim command As New SqlCommand("EXEC SecureLogin @userNAME=@username, @PASS=@password ", connection)

        command.Parameters.Add("@username", SqlDbType.VarChar).Value = TextBoxUsername.Text

        command.Parameters.Add("@password", SqlDbType.VarChar).Value = TextBoxPassword.Text

        Dim adapter As New SqlDataAdapter(command)

        Dim table As New DataTable()

        adapter.Fill(table)

        If table.Rows.Count() < 1 Then

            MessageBox.Show("Username or Password Are Invalid!")


        Else

            MessageBox.Show("Login Succesfully!")

            Dim frm As New Form2()
            Me.Hide()
            frm.show()


        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
