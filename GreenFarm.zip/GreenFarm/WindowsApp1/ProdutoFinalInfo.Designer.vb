﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProdutoFinalInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.cbxInfo = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 185)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(438, 17)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Procurar pelo produto final (dado o  numero do lote das sementes) :"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(12, 222)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(146, 29)
        Me.Button2.TabIndex = 9
        Me.Button2.Text = "Search "
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(510, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(518, 17)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Procurar informacão relativa às colheitas dos Produtos finais pelos funcionários " &
    ":"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(9, 322)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(489, 17)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Estatísticas associadas ao produto agrícula final :"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(15, 366)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(146, 29)
        Me.Button4.TabIndex = 15
        Me.Button4.Text = "Search "
        Me.Button4.UseVisualStyleBackColor = True
        '
        'dgv
        '
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(522, 158)
        Me.dgv.Name = "dgv"
        Me.dgv.RowTemplate.Height = 24
        Me.dgv.Size = New System.Drawing.Size(486, 299)
        Me.dgv.TabIndex = 16
        '
        'cbxInfo
        '
        Me.cbxInfo.FormattingEnabled = True
        Me.cbxInfo.Location = New System.Drawing.Point(822, 116)
        Me.cbxInfo.Name = "cbxInfo"
        Me.cbxInfo.Size = New System.Drawing.Size(186, 24)
        Me.cbxInfo.TabIndex = 17
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(597, 119)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(205, 17)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Selecione o NIF do funcionário:"
        '
        'ProdutoFinalInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1048, 511)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cbxInfo)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label2)
        Me.Name = "ProdutoFinalInfo"
        Me.Text = "ProdutoFinalInfo"
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents dgv As DataGridView
    Friend WithEvents cbxInfo As ComboBox
    Friend WithEvents Label5 As Label
End Class
