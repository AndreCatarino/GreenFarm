﻿Public Class StatsSementes

    Public SQL As New SqlControl


    Private Sub StatsSementes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadGridAllPlantacoes()
        LoadGridPlantacoesAboveAVG()
        LoadGridTotalSeedsByFunc()
        LoadStatistics()
    End Sub

    Private Sub LoadGridAllPlantacoes()

        SQL.ExeQuery("EXEC LotesDeSementes;")


        If SQL.RecordCount < 1 Then
            MsgBox("Error loading grid1")
            Exit Sub
        End If


        dgvAllPlantacoes.DataSource = SQL.DBT


    End Sub

    Private Sub LoadGridPlantacoesAboveAVG()

        SQL.ExeQuery("EXEC LotesDeSementesAboveAVGnuSementes;")

        If Sql.RecordCount < 1 Then
            MsgBox("Error loading grid2")
            Exit Sub
        End If


        dgvAboveAVG.DataSource = SQL.DBT


    End Sub


    Private Sub LoadGridTotalSeedsByFunc()

        SQL.ExeQuery("EXEC getTotalSeedsByFunc;")


        If SQL.RecordCount < 1 Then
            MsgBox("Error loading grid3")
            Exit Sub
        End If


        dgvTotalSeedByFunc.DataSource = SQL.DBT


    End Sub

    Private Sub LoadStatistics()

        SQL.ExeQuery("EXEC total_lotesSementes;")

        For Each r As DataRow In SQL.DBT.Rows
            txtNulotes.Text = r("total_LoteSeeds")
        Next

        If SQL.RecordCount < 1 Then
            MsgBox("Error loading totalSeeds")
            Exit Sub
        End If

        SQL.ExeQuery("EXEC AVGseedsNumber;")

        For Each r As DataRow In SQL.DBT.Rows
            txtAVGseedNu.Text = r("avgNusementes")
        Next

        If SQL.RecordCount < 1 Then
            MsgBox("Error loading avgSeedsNumber")
            Exit Sub
        End If

        SQL.ExeQuery("EXEC totalSeeds;")

        For Each r As DataRow In SQL.DBT.Rows
            txtTotalSeeds.Text = r("total_sementes")
        Next

        If SQL.RecordCount < 1 Then
            MsgBox("Error loading total seeds")
            Exit Sub
        End If

        SQL.ExeQuery("EXEC MAXQtdSeedsByLote;")

        Dim a As DataRow
        a = SQL.DBT.Rows(0)
        txtLoteMaisSeeds.Text = a("Nu_loteSementes")
        txtFuncPlantLote.Text = a("nome")

        If SQL.RecordCount < 1 Then Exit Sub

    End Sub


End Class