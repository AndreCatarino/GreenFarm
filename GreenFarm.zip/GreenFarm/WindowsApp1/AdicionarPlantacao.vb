﻿Public Class AdicionarPlantacao

    Private SQL As New SqlControl

    Private Sub AddPlantacao()
        'ADD SQL PARAMS AND RUN THE COMMAND 

        SQL.AddParam("@Germinacao", txtGerminacao.Text)
        SQL.AddParam("@NuLote", txtNuSementes.Text)
        SQL.AddParam("@NIFfornecedor", txtNIFfornecedor.Text)
        SQL.AddParam("@NIFfuncionario", txtNIFfuncionario.Text)
        SQL.AddParam("@data_plantio", txtDataPlantio.Text)
        SQL.AddParam("@Preservacao", txtPreservacao.Text)
        SQL.AddParam("@SeedNumber", txtSeedNumber.Text)

        SQL.ExeQuery("EXEC  InsertPlantacao @preservacao=@Preservacao,@germinacao=@Germinacao, @nuLoteSementes=@NuLote,@nifFunc=@NIFfuncionario,@nifForn=@NIFfornecedor,@dataPlantio=@data_plantio,@SeedNumb=@SeedNumber;")

        ' REPORT & ABORT ON ERRORS

        If SQL.HasException(True) Then Exit Sub

        MsgBox("Plantação do lote de sementes registado com sucesso !")

        Me.Hide()


    End Sub



    'BASIC VALIDATION
    Private Sub txtGerminacao_TextChanged(sender As Object, e As EventArgs) Handles txtGerminacao.TextChanged, txtPreservacao.TextChanged, txtNuSementes.TextChanged, txtNIFfornecedor.TextChanged, txtNIFfuncionario.TextChanged, txtDataPlantio.TextChanged, txtSeedNumber.TextChanged
        addbtn.Enabled = True
    End Sub

    Private Sub addbtn_Click(sender As Object, e As EventArgs) Handles addbtn.Click
        AddPlantacao()
    End Sub


End Class