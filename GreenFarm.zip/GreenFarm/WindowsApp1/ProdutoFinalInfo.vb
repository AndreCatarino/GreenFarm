﻿Public Class ProdutoFinalInfo


    Public SQL As New SqlControl


    Private Sub LoadCBX()
        ' REFRESH COMBO BOX
        cbxInfo.Items.Clear()

        ' RUN QUERY
        SQL.ExeQuery("Exec getFuncColheitaNif;")

        If SQL.HasException(True) Then Exit Sub 'error handling

        '   LOOP ROW AND ADD TO COMBOBOX
        For Each r As DataRow In SQL.DBT.Rows
            cbxInfo.Items.Add(r("Func_nif").ToString)
        Next


    End Sub

    Private Sub loadGridColheitas(NIF As Integer)

        SQL.AddParam("@NIF", NIF)
        SQL.ExeQuery("EXEC getColheitasPorFunc @NIFfuncionario = @NIF;")

        If SQL.RecordCount < 1 Then
            MsgBox("Funcionario selecionado não colheu nenhum produto final")
            Exit Sub
        End If


        dgv.DataSource = SQL.DBT

    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        PFinalInfo.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        SearchFinalProd.Show()
    End Sub

    Private Sub ProdutoFinalInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadCBX()
    End Sub

    Private Sub cbxInfo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxInfo.SelectedIndexChanged
        loadGridColheitas(cbxInfo.Text)
    End Sub
End Class