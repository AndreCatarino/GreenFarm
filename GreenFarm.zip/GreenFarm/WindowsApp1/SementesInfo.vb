﻿Public Class SementesInfo


    Public SQL As New SqlControl


    Private Sub LoadCBX()
        ' REFRESH COMBO BOX
        cbxItems.Items.Clear()

        ' RUN QUERY
        SQL.ExeQuery("EXEC getNIFfuncionario;")

        If SQL.HasException(True) Then Exit Sub 'error handling

        '   LOOP ROW AND ADD TO COMBOBOX
        For Each r As DataRow In SQL.DBT.Rows
            cbxItems.Items.Add(r("nif").ToString)
        Next

    End Sub


    Private Sub LoadCBX2()
        ' REFRESH COMBO BOX
        cbxNIFforn.Items.Clear()

        ' RUN QUERY
        SQL.ExeQuery("EXEC getNIFfornecedor;")

        If SQL.HasException(True) Then Exit Sub 'error handling

        '   LOOP ROW AND ADD TO COMBOBOX
        For Each r As DataRow In SQL.DBT.Rows
            cbxNIFforn.Items.Add(r("FORNnif").ToString)
        Next

    End Sub

    Private Sub SementesInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadCBX()
        LoadCBX2()
    End Sub


    Private Sub GetSeedsDetails(NIF As Integer)

        SQL.AddParam("@Nif", NIF)
        SQL.ExeQuery("EXEC SeedsDetails @nif = @Nif;")


        If SQL.RecordCount < 1 Then
            MsgBox("Funcionário selecionado não plantou nenhum lote de sementes")
            Exit Sub
        End If


        dgv.DataSource = SQL.DBT


    End Sub

    Private Sub GetSeedsDetails2(NIF As Integer)

        SQL.AddParam("@Nif", NIF)
        SQL.ExeQuery("EXEC SeedsDetails2 @NIF = @Nif;")


        If SQL.RecordCount < 1 Then
            MsgBox("Elemento selecionado não forneceu sementes para a estufa")
            Exit Sub
        End If


        dgv2.DataSource = SQL.DBT


    End Sub

    Private Sub cbxItems_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxItems.SelectedIndexChanged
        GetSeedsDetails(cbxItems.Text)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        AdicionarPlantacao.Show()
    End Sub

    Private Sub cbxNIFforn_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxNIFforn.SelectedIndexChanged
        GetSeedsDetails2(cbxNIFforn.Text)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        StatsSementes.Show()
    End Sub
End Class