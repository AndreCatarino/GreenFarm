﻿Public Class listCoop

    Public SQL As New SqlControl


    Public Sub LoadGrid(Optional query As String = "")

        If query = "" Then
            SQL.ExeQuery("EXEC CooperativasView;")

        Else
            SQL.ExeQuery(query)
        End If

        ' ERROR HANDLING
        If SQL.HasException(True) Then Exit Sub

        dgvData.DataSource = SQL.DBT


    End Sub

    Private Sub FindItem()
        SQL.AddParam("@nif", "%" & txtSearch.Text & "%")
        LoadGrid("Select * from Cooperativa where C_nif like @nif;")
    End Sub

    Private Sub Fornecedores_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'MdiParent = Form2
        LoadGrid()


    End Sub


    Private Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        FindItem()
    End Sub


End Class