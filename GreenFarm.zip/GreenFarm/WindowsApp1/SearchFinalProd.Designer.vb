﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SearchFinalProd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.cbxSeeds = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtPeso = New System.Windows.Forms.TextBox()
        Me.txtTempo = New System.Windows.Forms.TextBox()
        Me.txtEspecie = New System.Windows.Forms.TextBox()
        Me.txtFuncNIF = New System.Windows.Forms.TextBox()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtCoopNIF = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtLotePF = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtPreco = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cbxSeeds
        '
        Me.cbxSeeds.FormattingEnabled = True
        Me.cbxSeeds.Location = New System.Drawing.Point(56, 92)
        Me.cbxSeeds.Name = "cbxSeeds"
        Me.cbxSeeds.Size = New System.Drawing.Size(313, 24)
        Me.cbxSeeds.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(53, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(281, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Selecione o número de lote das sementes :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(283, 201)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Peso:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(261, 294)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 17)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Espécie :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(164, 247)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(163, 17)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Tempo de preservação :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(105, 335)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(222, 17)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "NIF do funcionário que o recolhe :"
        '
        'txtPeso
        '
        Me.txtPeso.Location = New System.Drawing.Point(333, 201)
        Me.txtPeso.Name = "txtPeso"
        Me.txtPeso.Size = New System.Drawing.Size(246, 22)
        Me.txtPeso.TabIndex = 6
        '
        'txtTempo
        '
        Me.txtTempo.Location = New System.Drawing.Point(333, 247)
        Me.txtTempo.Name = "txtTempo"
        Me.txtTempo.Size = New System.Drawing.Size(246, 22)
        Me.txtTempo.TabIndex = 7
        '
        'txtEspecie
        '
        Me.txtEspecie.Location = New System.Drawing.Point(333, 294)
        Me.txtEspecie.Name = "txtEspecie"
        Me.txtEspecie.Size = New System.Drawing.Size(246, 22)
        Me.txtEspecie.TabIndex = 8
        '
        'txtFuncNIF
        '
        Me.txtFuncNIF.Location = New System.Drawing.Point(333, 335)
        Me.txtFuncNIF.Name = "txtFuncNIF"
        Me.txtFuncNIF.Size = New System.Drawing.Size(246, 22)
        Me.txtFuncNIF.TabIndex = 9
        '
        'dgv
        '
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(592, 185)
        Me.dgv.Name = "dgv"
        Me.dgv.RowTemplate.Height = 24
        Me.dgv.Size = New System.Drawing.Size(475, 286)
        Me.dgv.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(589, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(478, 17)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Informações relativas à Cooperativa para qual o produto final foi escoado :"
        '
        'txtCoopNIF
        '
        Me.txtCoopNIF.Location = New System.Drawing.Point(333, 381)
        Me.txtCoopNIF.Name = "txtCoopNIF"
        Me.txtCoopNIF.Size = New System.Drawing.Size(246, 22)
        Me.txtCoopNIF.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(-5, 384)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(332, 17)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "NIF da Cooperativa para qual é escoado o produto:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(105, 454)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(220, 17)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Numero do lote do produto Final :"
        '
        'txtLotePF
        '
        Me.txtLotePF.Location = New System.Drawing.Point(333, 449)
        Me.txtLotePF.Name = "txtLotePF"
        Me.txtLotePF.Size = New System.Drawing.Size(246, 22)
        Me.txtLotePF.TabIndex = 15
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(272, 423)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 17)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Preço :"
        '
        'txtPreco
        '
        Me.txtPreco.Location = New System.Drawing.Point(333, 420)
        Me.txtPreco.Name = "txtPreco"
        Me.txtPreco.Size = New System.Drawing.Size(246, 22)
        Me.txtPreco.TabIndex = 17
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(92, 166)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(487, 17)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Informação relativa ao Produto Agrícula Final gerado pelo Lote selecionado:"
        '
        'SearchFinalProd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1123, 534)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtPreco)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtLotePF)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtCoopNIF)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.txtFuncNIF)
        Me.Controls.Add(Me.txtEspecie)
        Me.Controls.Add(Me.txtTempo)
        Me.Controls.Add(Me.txtPeso)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbxSeeds)
        Me.Name = "SearchFinalProd"
        Me.Text = "Procurar pelo Produto Final"
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cbxSeeds As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtPeso As TextBox
    Friend WithEvents txtTempo As TextBox
    Friend WithEvents txtEspecie As TextBox
    Friend WithEvents txtFuncNIF As TextBox
    Friend WithEvents dgv As DataGridView
    Friend WithEvents Label6 As Label
    Friend WithEvents txtCoopNIF As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtLotePF As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtPreco As TextBox
    Friend WithEvents Label10 As Label
End Class
