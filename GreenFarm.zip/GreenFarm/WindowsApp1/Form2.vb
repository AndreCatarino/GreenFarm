﻿Imports System.Data.SqlClient


Public Class Form2

    Private SQL As SqlControl


    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.BackColor = Color.FromArgb(255, 255, 255)


        ' LoadToolStripMenuItem_Click(sender, e) 


    End Sub



    Private Sub msiAdicionar_Click(sender As Object, e As EventArgs) Handles msiAdicionar.Click
        NewEquipment.Show()
    End Sub

    Private Sub msiAlterar_Click(sender As Object, e As EventArgs) Handles msiAlterar.Click
        UpdateEquip.Show()
    End Sub

    Private Sub msiRemover_Click(sender As Object, e As EventArgs) Handles msiRemover.Click
        DelEquip.Show()
    End Sub

    Private Sub ConsultarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConsultarToolStripMenuItem.Click
        EmployeesList.Show()
    End Sub

    Private Sub AdicionarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdicionarToolStripMenuItem.Click
        AddEmployee.Show()
    End Sub

    Private Sub RemoverToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoverToolStripMenuItem.Click
        RemEmployees.Show()
    End Sub

    Private Sub AtualizarFichaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AtualizarFichaToolStripMenuItem.Click
        UpdateEmp.Show()
    End Sub

    Private Sub ListarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListarToolStripMenuItem.Click
        Lista_Fornecedores.Show()
    End Sub

    Private Sub InserirNovoFornecedorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InserirNovoFornecedorToolStripMenuItem.Click
        InsertFornecedor.Show()
    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs)
        SearchFinalProd.Show()
    End Sub

    Private Sub RemoverToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles RemoverToolStripMenuItem1.Click
        RemoveSupplier.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        GerirEquipamentos.Show()
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        SementesInfo.Show()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        ProdutoFinalInfo.Show()
    End Sub

    Private Sub AdicionarToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AdicionarToolStripMenuItem1.Click
        addCoop.Show()
    End Sub

    Private Sub VeralterarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VeralterarToolStripMenuItem.Click
        listCoop.Show()
    End Sub

    Private Sub RemoverToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles RemoverToolStripMenuItem2.Click
        RemCoop.Show()
    End Sub


End Class