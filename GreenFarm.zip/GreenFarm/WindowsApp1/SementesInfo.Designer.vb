﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SementesInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbxItems = New System.Windows.Forms.ComboBox()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.dgv2 = New System.Windows.Forms.DataGridView()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cbxNIFforn = New System.Windows.Forms.ComboBox()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(48, 172)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(132, 17)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Registar Plantação:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 342)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(438, 17)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Procurar pelas sementes fornecidas por cada um dos fornecedores:"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(51, 207)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(146, 26)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Adicionar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(48, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(420, 17)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Procurar por detalhes de sementes plantadas pelos funcionários:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(48, 77)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(281, 17)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Selecione o NIF do funcionário pretendido :"
        '
        'cbxItems
        '
        Me.cbxItems.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxItems.FormattingEnabled = True
        Me.cbxItems.Location = New System.Drawing.Point(357, 74)
        Me.cbxItems.Name = "cbxItems"
        Me.cbxItems.Size = New System.Drawing.Size(349, 24)
        Me.cbxItems.TabIndex = 14
        '
        'dgv
        '
        Me.dgv.AllowUserToAddRows = False
        Me.dgv.AllowUserToDeleteRows = False
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(357, 123)
        Me.dgv.Name = "dgv"
        Me.dgv.ReadOnly = True
        Me.dgv.RowTemplate.Height = 24
        Me.dgv.Size = New System.Drawing.Size(349, 170)
        Me.dgv.TabIndex = 15
        '
        'dgv2
        '
        Me.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv2.Location = New System.Drawing.Point(15, 402)
        Me.dgv2.Name = "dgv2"
        Me.dgv2.RowTemplate.Height = 24
        Me.dgv2.Size = New System.Drawing.Size(435, 181)
        Me.dgv2.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(482, 463)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(282, 17)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "Estatísticas relacionadas com as sementes:"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(570, 494)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(86, 24)
        Me.Button1.TabIndex = 18
        Me.Button1.Text = "Search"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 375)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(280, 17)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Selecione o NIF do fornecedor pretendido :"
        '
        'cbxNIFforn
        '
        Me.cbxNIFforn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbxNIFforn.FormattingEnabled = True
        Me.cbxNIFforn.Location = New System.Drawing.Point(298, 372)
        Me.cbxNIFforn.Name = "cbxNIFforn"
        Me.cbxNIFforn.Size = New System.Drawing.Size(246, 24)
        Me.cbxNIFforn.TabIndex = 20
        '
        'SementesInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(776, 595)
        Me.Controls.Add(Me.cbxNIFforn)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.dgv2)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.cbxItems)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "SementesInfo"
        Me.Text = "SementesInfo"
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents cbxItems As ComboBox
    Friend WithEvents dgv As DataGridView
    Friend WithEvents dgv2 As DataGridView
    Friend WithEvents Label5 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents cbxNIFforn As ComboBox
End Class
