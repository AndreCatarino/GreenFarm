﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdicionarPlantacao
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtGerminacao = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtNuSementes = New System.Windows.Forms.TextBox()
        Me.txtNIFfuncionario = New System.Windows.Forms.TextBox()
        Me.txtNIFfornecedor = New System.Windows.Forms.TextBox()
        Me.txtDataPlantio = New System.Windows.Forms.TextBox()
        Me.txtPreservacao = New System.Windows.Forms.TextBox()
        Me.addbtn = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtSeedNumber = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'txtGerminacao
        '
        Me.txtGerminacao.Location = New System.Drawing.Point(230, 56)
        Me.txtGerminacao.Name = "txtGerminacao"
        Me.txtGerminacao.Size = New System.Drawing.Size(234, 22)
        Me.txtGerminacao.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(68, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(125, 17)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "tempo germinaçao"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(43, 126)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(150, 17)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Numero lote sementes"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(95, 240)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 17)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Nif fornecedor"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(90, 177)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(103, 17)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "NIF funcionario"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(108, 298)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(85, 17)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Data Plantio"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(106, 352)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(87, 17)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "preservacao"
        '
        'txtNuSementes
        '
        Me.txtNuSementes.Location = New System.Drawing.Point(230, 123)
        Me.txtNuSementes.Name = "txtNuSementes"
        Me.txtNuSementes.Size = New System.Drawing.Size(234, 22)
        Me.txtNuSementes.TabIndex = 14
        '
        'txtNIFfuncionario
        '
        Me.txtNIFfuncionario.Location = New System.Drawing.Point(230, 177)
        Me.txtNIFfuncionario.Name = "txtNIFfuncionario"
        Me.txtNIFfuncionario.Size = New System.Drawing.Size(234, 22)
        Me.txtNIFfuncionario.TabIndex = 15
        '
        'txtNIFfornecedor
        '
        Me.txtNIFfornecedor.Location = New System.Drawing.Point(230, 237)
        Me.txtNIFfornecedor.Name = "txtNIFfornecedor"
        Me.txtNIFfornecedor.Size = New System.Drawing.Size(234, 22)
        Me.txtNIFfornecedor.TabIndex = 16
        '
        'txtDataPlantio
        '
        Me.txtDataPlantio.Location = New System.Drawing.Point(230, 295)
        Me.txtDataPlantio.Name = "txtDataPlantio"
        Me.txtDataPlantio.Size = New System.Drawing.Size(234, 22)
        Me.txtDataPlantio.TabIndex = 17
        '
        'txtPreservacao
        '
        Me.txtPreservacao.Location = New System.Drawing.Point(230, 352)
        Me.txtPreservacao.Name = "txtPreservacao"
        Me.txtPreservacao.Size = New System.Drawing.Size(234, 22)
        Me.txtPreservacao.TabIndex = 18
        '
        'addbtn
        '
        Me.addbtn.Enabled = False
        Me.addbtn.Location = New System.Drawing.Point(230, 458)
        Me.addbtn.Name = "addbtn"
        Me.addbtn.Size = New System.Drawing.Size(234, 23)
        Me.addbtn.TabIndex = 19
        Me.addbtn.Text = "Adicionar Plantação do Lote"
        Me.addbtn.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 409)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(206, 17)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Número de sementes plantado:"
        '
        'txtSeedNumber
        '
        Me.txtSeedNumber.Location = New System.Drawing.Point(230, 406)
        Me.txtSeedNumber.Name = "txtSeedNumber"
        Me.txtSeedNumber.Size = New System.Drawing.Size(234, 22)
        Me.txtSeedNumber.TabIndex = 21
        '
        'AdicionarPlantacao
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(569, 493)
        Me.Controls.Add(Me.txtSeedNumber)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.addbtn)
        Me.Controls.Add(Me.txtPreservacao)
        Me.Controls.Add(Me.txtDataPlantio)
        Me.Controls.Add(Me.txtNIFfornecedor)
        Me.Controls.Add(Me.txtNIFfuncionario)
        Me.Controls.Add(Me.txtNuSementes)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtGerminacao)
        Me.Name = "AdicionarPlantacao"
        Me.Text = "AdicionarPlantacao"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtGerminacao As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtNuSementes As TextBox
    Friend WithEvents txtNIFfuncionario As TextBox
    Friend WithEvents txtNIFfornecedor As TextBox
    Friend WithEvents txtDataPlantio As TextBox
    Friend WithEvents txtPreservacao As TextBox
    Friend WithEvents addbtn As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents txtSeedNumber As TextBox
End Class
