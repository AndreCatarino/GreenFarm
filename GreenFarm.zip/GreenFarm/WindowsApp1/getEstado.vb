﻿Public Class getEstado

    Public SQL As New SqlControl

    Private Sub LoadCBX()
        ' REFRESH COMBO BOX
        cbxNuserie.Items.Clear()

        ' RUN QUERY
        SQL.ExeQuery("EXEC getSerialNUmber;") 'mudar pra tabela manutencao

        If SQL.HasException(True) Then Exit Sub 'error handling

        '   LOOP ROW AND ADD TO COMBOBOX
        For Each r As DataRow In SQL.DBT.Rows
            cbxNuserie.Items.Add(r("Nu_serie").ToString)
        Next


    End Sub


    Private Sub GetManutencaoStatus(nuSerie As Integer)

        SQL.AddParam("@nuSerie", nuSerie)
        SQL.ExeQuery("EXEC ManutencaoStatus @SerialNu = @nuSerie;")


        If SQL.RecordCount < 1 Then
            MsgBox("O equipamento em causa nao se encontra em manutencao")
            Exit Sub
        End If

        For Each r As DataRow In SQL.DBT.Rows
            txtPeso.Text = r("estado")
            txt.Text = r("joindate")

        Next


    End Sub



    Private Sub getEstado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadCBX()
        LoadGrid()
    End Sub

    Private Sub LoadGrid()

        SQL.ExeQuery("EXEC getTableEquipManutencao;")

        ' ERROR HANDLING
        If SQL.HasException(True) Then
            Exit Sub
        End If

        dgv.DataSource = SQL.DBT


    End Sub

    Private Sub cbxSeeds_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxNuserie.SelectedIndexChanged
        GetManutencaoStatus(cbxNuserie.Text)
    End Sub

    Private Sub addManutencao()

        'ADD SQL PARAMS AND RUN THE COMMAND 

        SQL.AddParam("@IDman", txtIDmanEquip.Text)
        SQL.AddParam("@SerialNumber", txtNuSerie.Text)
        SQL.AddParam("@data", txtDate.Text)
        SQL.AddParam("@estado", txtState.Text)
        SQL.AddParam("@tipo", txtTipo.Text)


        SQL.ExeQuery("EXEC addToManutencao @nu_serie=@SerialNumber,@ID=@IDman,@date=@data,@state=@estado,@type=@tipo;")

        If SQL.HasException(True) Then Exit Sub

        MsgBox("Equipamento foi enviado para a manutenção com sucesso !")

        Me.Hide()
    End Sub

    Private Sub addMan_Click(sender As Object, e As EventArgs) Handles addMan.Click
        addManutencao()
        addMan.Enabled = False
    End Sub

End Class