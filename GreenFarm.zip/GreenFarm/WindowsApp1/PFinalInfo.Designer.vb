﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PFinalInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.sdf = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtLowVal = New System.Windows.Forms.TextBox()
        Me.txtHighVal = New System.Windows.Forms.TextBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtHigherDur = New System.Windows.Forms.ListBox()
        Me.txtHighestPrice = New System.Windows.Forms.ListView()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(41, 337)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(374, 17)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Lote do Produto final com o maior tempo de durabilidade: "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(131, 428)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(269, 17)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "Lote do Produto final com o maior preço: "
        '
        'dgv
        '
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(51, 104)
        Me.dgv.Name = "dgv"
        Me.dgv.RowTemplate.Height = 24
        Me.dgv.Size = New System.Drawing.Size(575, 190)
        Me.dgv.TabIndex = 24
        '
        'sdf
        '
        Me.sdf.AutoSize = True
        Me.sdf.Location = New System.Drawing.Point(48, 26)
        Me.sdf.Name = "sdf"
        Me.sdf.Size = New System.Drawing.Size(248, 17)
        Me.sdf.TabIndex = 25
        Me.sdf.Text = "Produtos finais registados no sistema:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(-2, 57)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(545, 17)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "Procure pelos lotes dos produtos finais compreendidos entre o intervalo que desej" &
    "ar:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(644, 57)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(13, 17)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "-"
        '
        'txtLowVal
        '
        Me.txtLowVal.Location = New System.Drawing.Point(538, 57)
        Me.txtLowVal.Name = "txtLowVal"
        Me.txtLowVal.Size = New System.Drawing.Size(100, 22)
        Me.txtLowVal.TabIndex = 28
        '
        'txtHighVal
        '
        Me.txtHighVal.Location = New System.Drawing.Point(663, 57)
        Me.txtHighVal.Name = "txtHighVal"
        Me.txtHighVal.Size = New System.Drawing.Size(100, 22)
        Me.txtHighVal.TabIndex = 29
        '
        'btnSearch
        '
        Me.btnSearch.Enabled = False
        Me.btnSearch.Location = New System.Drawing.Point(786, 53)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(84, 23)
        Me.btnSearch.TabIndex = 30
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'txtHigherDur
        '
        Me.txtHigherDur.FormattingEnabled = True
        Me.txtHigherDur.ItemHeight = 16
        Me.txtHigherDur.Location = New System.Drawing.Point(421, 318)
        Me.txtHigherDur.Name = "txtHigherDur"
        Me.txtHigherDur.Size = New System.Drawing.Size(190, 68)
        Me.txtHigherDur.TabIndex = 31
        '
        'txtHighestPrice
        '
        Me.txtHighestPrice.Location = New System.Drawing.Point(421, 410)
        Me.txtHighestPrice.Name = "txtHighestPrice"
        Me.txtHighestPrice.Size = New System.Drawing.Size(190, 67)
        Me.txtHighestPrice.TabIndex = 32
        Me.txtHighestPrice.UseCompatibleStateImageBehavior = False
        '
        'PFinalInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(895, 476)
        Me.Controls.Add(Me.txtHighestPrice)
        Me.Controls.Add(Me.txtHigherDur)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.txtHighVal)
        Me.Controls.Add(Me.txtLowVal)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.sdf)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label11)
        Me.Name = "PFinalInfo"
        Me.Text = "PFinalInfo"
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label11 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents dgv As DataGridView
    Friend WithEvents sdf As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtLowVal As TextBox
    Friend WithEvents txtHighVal As TextBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtHigherDur As ListBox
    Friend WithEvents txtHighestPrice As ListView
End Class
