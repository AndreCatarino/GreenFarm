﻿Public Class addCoop

    Private SQL As New SqlControl

    Private Sub InsertCoop()
        'ADD SQL PARAMS AND RUN THE COMMAND 

        SQL.AddParam("@nif", txtNIF.Text)
        SQL.AddParam("@name", txtNome.Text)
        SQL.AddParam("@Cotas", txtCotas.Text)
        SQL.AddParam("@Fundos", txtFundos.Text)

        SQL.ExeQuery("EXEC NewCooperativa @cooperativaNIF=@nif, @CotasMensais=@Cotas, @funds=@Fundos, @nome=@name;")


        ' REPORT & ABORT ON ERRORS

        If SQL.HasException(True) Then Exit Sub

        MsgBox("Cooperativa registada com sucesso !")

        If SQL.DBT.Rows.Count > 0 Then
            Dim r As DataRow = SQL.DBT.Rows(0)
        End If

        Me.Hide()

    End Sub


    Private Sub adicionarCoop_Click(sender As Object, e As EventArgs) Handles adicionarCoop.Click
        InsertCoop()
    End Sub

    Private Sub addCoop_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class