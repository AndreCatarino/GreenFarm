﻿Public Class UpdateEquip


    Private SQL As New SqlControl

    Private Sub FetchEquipamentos()
        ' REFRESH EQUIPAMENTOS LIST
        lbEquipamentos.Items.Clear()

        ' ADD PARAMS & RUN QUERY
        SQL.AddParam("@nu_serie", "%" & txtFilter.Text & "%")

        SQL.ExeQuery("SELECT Nu_serie " & "FROM Equipamento " &
                        "WHERE Nu_serie LIKE @nu_serie;")
        'REPORT AND ABORT ON ERRORS

        If SQL.HasException(True) Then Exit Sub

        'LOOP ROWS AND RETURN EQUIPAMENTOS TO LIST

        For Each r As DataRow In SQL.DBT.Rows
            lbEquipamentos.Items.Add(r("Nu_serie"))
        Next

    End Sub


    Private Sub GetEquipmentsDetails(Nu_serie As Integer)
        SQL.AddParam("@nu_serie", Nu_serie)
        SQL.ExeQuery("Select * FROM Equipamento WHERE Nu_serie = @nu_serie;")

        If SQL.RecordCount < 1 Then Exit Sub

        For Each r As DataRow In SQL.DBT.Rows
            txtSerialNumber.Text = r("Nu_serie")
            txtTipoEquipamento.Text = r("tipo_equipamento")
            txtCombustivel.Text = r("combustivel")
            txtMarca.Text = r("marca")
        Next

    End Sub


    Private Sub UpdateEquipamentos()
        SQL.AddParam("@tipoEquipamento", txtTipoEquipamento.Text)
        SQL.AddParam("@combustivel", txtCombustivel.Text)
        SQL.AddParam("@marca", txtMarca.Text)
        SQL.AddParam("@nu_serie", txtSerialNumber.Text)

        SQL.ExeQuery("UPDATE Equipamento SET tipo_equipamento=@tipoEquipamento, marca=@marca, combustivel=@combustivel WHERE Nu_serie=@nu_serie;")

        If SQL.HasException(True) Then Exit Sub

        MsgBox("Detalhes do equipamento foram atualizados !")

        'btnALTER.Enabled = True
    End Sub


    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FetchEquipamentos()
    End Sub


    Private Sub txtFilter_KeyDown(sender As Object, e As KeyEventArgs) Handles txtFilter.KeyDown
        If e.KeyCode = Keys.Enter Then
            FetchEquipamentos()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub


    Private Sub lbEquipamentos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbEquipamentos.SelectedIndexChanged
        GetEquipmentsDetails(lbEquipamentos.Text)
    End Sub


    Private Sub btnALTER_Click(sender As Object, e As EventArgs) Handles btnALTER.Click
        UpdateEquipamentos()
    End Sub


End Class