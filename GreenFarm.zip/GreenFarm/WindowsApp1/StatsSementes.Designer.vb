﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StatsSementes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dgvAllPlantacoes = New System.Windows.Forms.DataGridView()
        Me.dgvTotalSeedByFunc = New System.Windows.Forms.DataGridView()
        Me.txtTotalSeeds = New System.Windows.Forms.TextBox()
        Me.txtAVGseedNu = New System.Windows.Forms.TextBox()
        Me.txtLoteMaisSeeds = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.txtFuncPlantLote = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtNulotes = New System.Windows.Forms.TextBox()
        Me.dgvAboveAVG = New System.Windows.Forms.DataGridView()
        Me.Label7 = New System.Windows.Forms.Label()
        CType(Me.dgvAllPlantacoes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvTotalSeedByFunc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvAboveAVG, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 285)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(182, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Número total de sementes :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 377)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(311, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Número médio de sementes plantadas por lote :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(22, 330)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(301, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Nº do Lote com o maior número de sementes: "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(25, 29)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(304, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Todas as Plantações de sementes registadas :"
        '
        'dgvAllPlantacoes
        '
        Me.dgvAllPlantacoes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvAllPlantacoes.Location = New System.Drawing.Point(15, 58)
        Me.dgvAllPlantacoes.Name = "dgvAllPlantacoes"
        Me.dgvAllPlantacoes.RowTemplate.Height = 24
        Me.dgvAllPlantacoes.Size = New System.Drawing.Size(352, 204)
        Me.dgvAllPlantacoes.TabIndex = 4
        '
        'dgvTotalSeedByFunc
        '
        Me.dgvTotalSeedByFunc.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvTotalSeedByFunc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTotalSeedByFunc.Location = New System.Drawing.Point(407, 449)
        Me.dgvTotalSeedByFunc.Name = "dgvTotalSeedByFunc"
        Me.dgvTotalSeedByFunc.RowTemplate.Height = 24
        Me.dgvTotalSeedByFunc.Size = New System.Drawing.Size(372, 176)
        Me.dgvTotalSeedByFunc.TabIndex = 6
        '
        'txtTotalSeeds
        '
        Me.txtTotalSeeds.Cursor = System.Windows.Forms.Cursors.Default
        Me.txtTotalSeeds.Location = New System.Drawing.Point(200, 285)
        Me.txtTotalSeeds.Name = "txtTotalSeeds"
        Me.txtTotalSeeds.Size = New System.Drawing.Size(119, 22)
        Me.txtTotalSeeds.TabIndex = 7
        '
        'txtAVGseedNu
        '
        Me.txtAVGseedNu.Location = New System.Drawing.Point(329, 374)
        Me.txtAVGseedNu.Name = "txtAVGseedNu"
        Me.txtAVGseedNu.Size = New System.Drawing.Size(92, 22)
        Me.txtAVGseedNu.TabIndex = 8
        '
        'txtLoteMaisSeeds
        '
        Me.txtLoteMaisSeeds.Location = New System.Drawing.Point(329, 327)
        Me.txtLoteMaisSeeds.Name = "txtLoteMaisSeeds"
        Me.txtLoteMaisSeeds.Size = New System.Drawing.Size(78, 22)
        Me.txtLoteMaisSeeds.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(425, 330)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(211, 17)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "plantado por (nome funcionário)"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'txtFuncPlantLote
        '
        Me.txtFuncPlantLote.Location = New System.Drawing.Point(642, 327)
        Me.txtFuncPlantLote.Name = "txtFuncPlantLote"
        Me.txtFuncPlantLote.Size = New System.Drawing.Size(126, 22)
        Me.txtFuncPlantLote.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Label5.Location = New System.Drawing.Point(404, 419)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(375, 17)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Número total de sementes plantado por cada funcionário :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(12, 467)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(335, 17)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = " Número de lotes de sementes existentes na estufa:"
        '
        'txtNulotes
        '
        Me.txtNulotes.Location = New System.Drawing.Point(15, 496)
        Me.txtNulotes.Name = "txtNulotes"
        Me.txtNulotes.Size = New System.Drawing.Size(132, 22)
        Me.txtNulotes.TabIndex = 19
        '
        'dgvAboveAVG
        '
        Me.dgvAboveAVG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvAboveAVG.Location = New System.Drawing.Point(407, 58)
        Me.dgvAboveAVG.Name = "dgvAboveAVG"
        Me.dgvAboveAVG.RowTemplate.Height = 24
        Me.dgvAboveAVG.Size = New System.Drawing.Size(372, 204)
        Me.dgvAboveAVG.TabIndex = 20
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(386, 29)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(410, 17)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Lotes com um número de sementes plantadas acima da média :"
        '
        'StatsSementes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(795, 647)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.dgvAboveAVG)
        Me.Controls.Add(Me.txtNulotes)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtFuncPlantLote)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtLoteMaisSeeds)
        Me.Controls.Add(Me.txtAVGseedNu)
        Me.Controls.Add(Me.txtTotalSeeds)
        Me.Controls.Add(Me.dgvTotalSeedByFunc)
        Me.Controls.Add(Me.dgvAllPlantacoes)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Cursor = System.Windows.Forms.Cursors.AppStarting
        Me.Name = "StatsSementes"
        Me.Text = "StatsSementes"
        CType(Me.dgvAllPlantacoes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvTotalSeedByFunc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvAboveAVG, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents dgvAllPlantacoes As DataGridView
    Friend WithEvents dgvTotalSeedByFunc As DataGridView
    Friend WithEvents txtTotalSeeds As TextBox
    Friend WithEvents txtAVGseedNu As TextBox
    Friend WithEvents txtLoteMaisSeeds As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents txtFuncPlantLote As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txtNulotes As TextBox
    Friend WithEvents dgvAboveAVG As DataGridView
    Friend WithEvents Label7 As Label
End Class
