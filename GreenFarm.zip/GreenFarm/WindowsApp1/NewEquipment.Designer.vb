﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NewEquipment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.txtNumeroSerie = New System.Windows.Forms.TextBox()
        Me.txtTipoEquipamento = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtMarca = New System.Windows.Forms.TextBox()
        Me.txtCombustivel = New System.Windows.Forms.TextBox()
        Me.combustivel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdAdd
        '
        Me.cmdAdd.Enabled = False
        Me.cmdAdd.Location = New System.Drawing.Point(200, 316)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(219, 23)
        Me.cmdAdd.TabIndex = 0
        Me.cmdAdd.Text = "ADICIONAR EQUIPAMENTO"
        Me.cmdAdd.UseVisualStyleBackColor = True
        '
        'txtNumeroSerie
        '
        Me.txtNumeroSerie.Location = New System.Drawing.Point(200, 62)
        Me.txtNumeroSerie.Name = "txtNumeroSerie"
        Me.txtNumeroSerie.Size = New System.Drawing.Size(230, 22)
        Me.txtNumeroSerie.TabIndex = 1
        '
        'txtTipoEquipamento
        '
        Me.txtTipoEquipamento.Location = New System.Drawing.Point(200, 123)
        Me.txtTipoEquipamento.Name = "txtTipoEquipamento"
        Me.txtTipoEquipamento.Size = New System.Drawing.Size(230, 22)
        Me.txtTipoEquipamento.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(60, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(125, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Numero de série : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(45, 123)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(146, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Tipo de quipamento : "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(126, 188)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Marca : "
        '
        'txtMarca
        '
        Me.txtMarca.Location = New System.Drawing.Point(200, 183)
        Me.txtMarca.Name = "txtMarca"
        Me.txtMarca.Size = New System.Drawing.Size(230, 22)
        Me.txtMarca.TabIndex = 6
        '
        'txtCombustivel
        '
        Me.txtCombustivel.Location = New System.Drawing.Point(200, 231)
        Me.txtCombustivel.Name = "txtCombustivel"
        Me.txtCombustivel.Size = New System.Drawing.Size(230, 22)
        Me.txtCombustivel.TabIndex = 8
        '
        'combustivel
        '
        Me.combustivel.AutoSize = True
        Me.combustivel.Location = New System.Drawing.Point(89, 236)
        Me.combustivel.Name = "combustivel"
        Me.combustivel.Size = New System.Drawing.Size(96, 17)
        Me.combustivel.TabIndex = 9
        Me.combustivel.Text = "Combustivel : "
        '
        'NewEquipment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(637, 361)
        Me.Controls.Add(Me.combustivel)
        Me.Controls.Add(Me.txtCombustivel)
        Me.Controls.Add(Me.txtMarca)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtTipoEquipamento)
        Me.Controls.Add(Me.txtNumeroSerie)
        Me.Controls.Add(Me.cmdAdd)
        Me.Name = "NewEquipment"
        Me.Text = "NewEquipment"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmdAdd As Button
    Friend WithEvents txtNumeroSerie As TextBox
    Friend WithEvents txtTipoEquipamento As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtMarca As TextBox
    Friend WithEvents txtCombustivel As TextBox
    Friend WithEvents combustivel As Label
End Class
