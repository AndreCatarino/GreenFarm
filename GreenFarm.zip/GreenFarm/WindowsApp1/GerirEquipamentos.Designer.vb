﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GerirEquipamentos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.dgvSupplyDetails = New System.Windows.Forms.DataGridView()
        Me.dgvEquipUtil = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbxFORN = New System.Windows.Forms.ComboBox()
        Me.cbxEquipUtil = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.dgvSupplyDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvEquipUtil, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvSupplyDetails
        '
        Me.dgvSupplyDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSupplyDetails.Location = New System.Drawing.Point(12, 123)
        Me.dgvSupplyDetails.Name = "dgvSupplyDetails"
        Me.dgvSupplyDetails.RowTemplate.Height = 24
        Me.dgvSupplyDetails.Size = New System.Drawing.Size(349, 215)
        Me.dgvSupplyDetails.TabIndex = 0
        '
        'dgvEquipUtil
        '
        Me.dgvEquipUtil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvEquipUtil.Location = New System.Drawing.Point(453, 123)
        Me.dgvEquipUtil.Name = "dgvEquipUtil"
        Me.dgvEquipUtil.RowTemplate.Height = 24
        Me.dgvEquipUtil.Size = New System.Drawing.Size(340, 215)
        Me.dgvEquipUtil.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(372, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Detalhes do fornecimento de cada um dos equipamentos:"
        '
        'cbxFORN
        '
        Me.cbxFORN.FormattingEnabled = True
        Me.cbxFORN.Location = New System.Drawing.Point(12, 93)
        Me.cbxFORN.Name = "cbxFORN"
        Me.cbxFORN.Size = New System.Drawing.Size(191, 24)
        Me.cbxFORN.TabIndex = 3
        '
        'cbxEquipUtil
        '
        Me.cbxEquipUtil.FormattingEnabled = True
        Me.cbxEquipUtil.Location = New System.Drawing.Point(566, 93)
        Me.cbxEquipUtil.Name = "cbxEquipUtil"
        Me.cbxEquipUtil.Size = New System.Drawing.Size(222, 24)
        Me.cbxEquipUtil.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(516, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(260, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Equipamentos atualmente em Utilização"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(230, 96)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(317, 17)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "(Pesquisa por número de Série do Equipamento)"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 381)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(316, 23)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Ver estados dos equipamento em Manutenção"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'GerirEquipamentos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(843, 452)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cbxEquipUtil)
        Me.Controls.Add(Me.cbxFORN)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgvEquipUtil)
        Me.Controls.Add(Me.dgvSupplyDetails)
        Me.Name = "GerirEquipamentos"
        Me.Text = "GerirEquipamentos"
        CType(Me.dgvSupplyDetails, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvEquipUtil, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvSupplyDetails As DataGridView
    Friend WithEvents dgvEquipUtil As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents cbxFORN As ComboBox
    Friend WithEvents cbxEquipUtil As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
End Class
