﻿Public Class EmployeesList

    Public SQL As New SqlControl '(other machine override)

    Public Sub LoadGrid(Optional query As String = "")

        If query = "" Then
            SQL.ExeQuery("EXEC listFuncionarios;")

        Else
            SQL.ExeQuery(query)
        End If

        ' ERROR HANDLING
        If SQL.HasException(True) Then Exit Sub

        dgvdata.DataSource = SQL.DBT


    End Sub

    Private Sub FindFunc()
        SQL.AddParam("@nif", "%" & txtSearch.Text & "%")
        LoadGrid("EXEC SearchFuncByNIF @item = @nif;")
    End Sub

    Private Sub Employees_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'MdiParent = Form2
        LoadGrid()
        LoadCBX()

    End Sub

    Private Sub LoadCBX()
        ' REFRESH COMBO BOX
        cbxItems.Items.Clear()

        ' RUN QUERY
        SQL.ExeQuery("EXEC FuncsName;")

        If SQL.HasException(True) Then Exit Sub 'error handling

        '   LOOP ROW AND ADD TO COMBOBOX
        For Each r As DataRow In SQL.DBT.Rows
            cbxItems.Items.Add(r("nome").ToString)
        Next


    End Sub

    Private Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        FindFunc()
    End Sub


End Class