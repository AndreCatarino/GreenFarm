﻿Public Class PFinalInfo

    Public SQL As New SqlControl

    Private Sub PFinalInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadGrid()
        LoadInfo()
    End Sub

    Private Sub LoadGrid()
        SQL.ExeQuery("EXEC listProdFinal;")

        ' ERROR HANDLING
        If SQL.HasException(True) Then Exit Sub

        dgv.DataSource = SQL.DBT

    End Sub

    Private Sub txtLowVal_TextChanged(sender As Object, e As EventArgs) Handles txtLowVal.TextChanged, txtHighVal.TextChanged
        btnSearch.Enabled = True
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        LoadFilteredGrid()
        'loadInfo()
    End Sub

    Private Sub LoadFilteredGrid()

        SQL.AddParam("@LowVal", txtLowVal.Text)
        SQL.AddParam("@HighVal", txtHighVal.Text)

        SQL.ExeQuery("EXEC RangePF @nuLoteInicial=@LowVal,@nuLoteFinal=@HighVal;")

        ' ERROR HANDLING
        If SQL.HasException(True) Then Exit Sub

        dgv.DataSource = SQL.DBT


    End Sub

    Private Sub LoadInfo()

        SQL.ExeQuery("EXEC getTheHighestDurability;")


        If SQL.RecordCount < 1 Then Exit Sub

        For Each r As DataRow In SQL.DBT.Rows
            txtHigherDur.Items.Add(r("nu_loteProdFinal"))
        Next


        SQL.ExeQuery("EXEC getTheHighestPrice;")

        If SQL.RecordCount < 1 Then Exit Sub

        For Each r As DataRow In SQL.DBT.Rows
            txtHighestPrice.Items.Add(r("nu_loteProdFinal"))
        Next

    End Sub


End Class