﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.msMain = New System.Windows.Forms.MenuStrip()
        Me.miEmployees = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdicionarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AtualizarFichaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EquipamentoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.msiAlterar = New System.Windows.Forms.ToolStripMenuItem()
        Me.msiAdicionar = New System.Windows.Forms.ToolStripMenuItem()
        Me.msiRemover = New System.Windows.Forms.ToolStripMenuItem()
        Me.FornecedoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InserirNovoFornecedorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoverToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CooperativasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdicionarToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VeralterarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoverToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.msMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'msMain
        '
        Me.msMain.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.msMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEmployees, Me.EquipamentoToolStripMenuItem, Me.FornecedoresToolStripMenuItem, Me.CooperativasToolStripMenuItem})
        Me.msMain.Location = New System.Drawing.Point(0, 0)
        Me.msMain.Name = "msMain"
        Me.msMain.Size = New System.Drawing.Size(605, 28)
        Me.msMain.TabIndex = 2
        Me.msMain.Text = "MenuStrip1"
        '
        'miEmployees
        '
        Me.miEmployees.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConsultarToolStripMenuItem, Me.AdicionarToolStripMenuItem, Me.RemoverToolStripMenuItem, Me.AtualizarFichaToolStripMenuItem})
        Me.miEmployees.Name = "miEmployees"
        Me.miEmployees.Size = New System.Drawing.Size(105, 24)
        Me.miEmployees.Text = "Empregados"
        '
        'ConsultarToolStripMenuItem
        '
        Me.ConsultarToolStripMenuItem.Name = "ConsultarToolStripMenuItem"
        Me.ConsultarToolStripMenuItem.Size = New System.Drawing.Size(216, 26)
        Me.ConsultarToolStripMenuItem.Text = "Consultar"
        '
        'AdicionarToolStripMenuItem
        '
        Me.AdicionarToolStripMenuItem.Name = "AdicionarToolStripMenuItem"
        Me.AdicionarToolStripMenuItem.Size = New System.Drawing.Size(216, 26)
        Me.AdicionarToolStripMenuItem.Text = "Adicionar"
        '
        'RemoverToolStripMenuItem
        '
        Me.RemoverToolStripMenuItem.Name = "RemoverToolStripMenuItem"
        Me.RemoverToolStripMenuItem.Size = New System.Drawing.Size(216, 26)
        Me.RemoverToolStripMenuItem.Text = "Remover"
        '
        'AtualizarFichaToolStripMenuItem
        '
        Me.AtualizarFichaToolStripMenuItem.Name = "AtualizarFichaToolStripMenuItem"
        Me.AtualizarFichaToolStripMenuItem.Size = New System.Drawing.Size(216, 26)
        Me.AtualizarFichaToolStripMenuItem.Text = "Atualizar dados"
        '
        'EquipamentoToolStripMenuItem
        '
        Me.EquipamentoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.msiAlterar, Me.msiAdicionar, Me.msiRemover})
        Me.EquipamentoToolStripMenuItem.Name = "EquipamentoToolStripMenuItem"
        Me.EquipamentoToolStripMenuItem.Size = New System.Drawing.Size(110, 24)
        Me.EquipamentoToolStripMenuItem.Text = "Equipamento"
        '
        'msiAlterar
        '
        Me.msiAlterar.Name = "msiAlterar"
        Me.msiAlterar.Size = New System.Drawing.Size(261, 26)
        Me.msiAlterar.Text = "Ver Equipamentos (alterar)"
        '
        'msiAdicionar
        '
        Me.msiAdicionar.Name = "msiAdicionar"
        Me.msiAdicionar.Size = New System.Drawing.Size(261, 26)
        Me.msiAdicionar.Text = "Adicionar"
        '
        'msiRemover
        '
        Me.msiRemover.Name = "msiRemover"
        Me.msiRemover.Size = New System.Drawing.Size(261, 26)
        Me.msiRemover.Text = "Remover"
        '
        'FornecedoresToolStripMenuItem
        '
        Me.FornecedoresToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListarToolStripMenuItem, Me.InserirNovoFornecedorToolStripMenuItem, Me.RemoverToolStripMenuItem1})
        Me.FornecedoresToolStripMenuItem.Name = "FornecedoresToolStripMenuItem"
        Me.FornecedoresToolStripMenuItem.Size = New System.Drawing.Size(110, 24)
        Me.FornecedoresToolStripMenuItem.Text = "Fornecedores"
        '
        'ListarToolStripMenuItem
        '
        Me.ListarToolStripMenuItem.Name = "ListarToolStripMenuItem"
        Me.ListarToolStripMenuItem.Size = New System.Drawing.Size(240, 26)
        Me.ListarToolStripMenuItem.Text = "Listar"
        '
        'InserirNovoFornecedorToolStripMenuItem
        '
        Me.InserirNovoFornecedorToolStripMenuItem.Name = "InserirNovoFornecedorToolStripMenuItem"
        Me.InserirNovoFornecedorToolStripMenuItem.Size = New System.Drawing.Size(240, 26)
        Me.InserirNovoFornecedorToolStripMenuItem.Text = "Inserir novo Fornecedor"
        '
        'RemoverToolStripMenuItem1
        '
        Me.RemoverToolStripMenuItem1.Name = "RemoverToolStripMenuItem1"
        Me.RemoverToolStripMenuItem1.Size = New System.Drawing.Size(240, 26)
        Me.RemoverToolStripMenuItem1.Text = "Remover"
        '
        'CooperativasToolStripMenuItem
        '
        Me.CooperativasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AdicionarToolStripMenuItem1, Me.VeralterarToolStripMenuItem, Me.RemoverToolStripMenuItem2})
        Me.CooperativasToolStripMenuItem.Name = "CooperativasToolStripMenuItem"
        Me.CooperativasToolStripMenuItem.Size = New System.Drawing.Size(108, 24)
        Me.CooperativasToolStripMenuItem.Text = "Cooperativas"
        '
        'AdicionarToolStripMenuItem1
        '
        Me.AdicionarToolStripMenuItem1.Name = "AdicionarToolStripMenuItem1"
        Me.AdicionarToolStripMenuItem1.Size = New System.Drawing.Size(148, 26)
        Me.AdicionarToolStripMenuItem1.Text = "Adicionar"
        '
        'VeralterarToolStripMenuItem
        '
        Me.VeralterarToolStripMenuItem.Name = "VeralterarToolStripMenuItem"
        Me.VeralterarToolStripMenuItem.Size = New System.Drawing.Size(148, 26)
        Me.VeralterarToolStripMenuItem.Text = "Listar"
        '
        'RemoverToolStripMenuItem2
        '
        Me.RemoverToolStripMenuItem2.Name = "RemoverToolStripMenuItem2"
        Me.RemoverToolStripMenuItem2.Size = New System.Drawing.Size(148, 26)
        Me.RemoverToolStripMenuItem2.Text = "Remover"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(161, 364)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(238, 77)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "Gestao do Stock do Equipamento"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(161, 117)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(238, 60)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "Gestao do stock de sementes"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(161, 228)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(238, 73)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Gestao do Stock do Produto Final"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(605, 518)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.msMain)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.msMain
        Me.Name = "Form2"
        Me.Opacity = 0.9R
        Me.Text = "Green Farm"
        Me.msMain.ResumeLayout(False)
        Me.msMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents msMain As MenuStrip
    Friend WithEvents miEmployees As ToolStripMenuItem
    Friend WithEvents EquipamentoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents msiAdicionar As ToolStripMenuItem
    Friend WithEvents msiRemover As ToolStripMenuItem
    Friend WithEvents msiAlterar As ToolStripMenuItem
    Friend WithEvents ConsultarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AdicionarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoverToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AtualizarFichaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FornecedoresToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ListarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InserirNovoFornecedorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoverToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents Button3 As Button
    Friend WithEvents CooperativasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AdicionarToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents VeralterarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoverToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
End Class
