﻿Public Class SearchFinalProd
    Public SQL As New SqlControl


    Private Sub LoadCBX()
        ' REFRESH COMBO BOX
        cbxSeeds.Items.Clear()

        ' RUN QUERY
        SQL.ExeQuery("Select Nu_loteSementes from Sementes;")

        If SQL.HasException(True) Then Exit Sub 'error handling

        '   LOOP ROW AND ADD TO COMBOBOX
        For Each r As DataRow In SQL.DBT.Rows
            cbxSeeds.Items.Add(r("Nu_loteSementes").ToString)
        Next


    End Sub

    Private Sub SearchFinalProd_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadCBX()
        'LoadGrid()
    End Sub


    Private Sub GetFinalProdDetails(loteSementes As Integer)

        SQL.AddParam("@loteSem", loteSementes)
        SQL.ExeQuery("Select * From dbo.getProdFinal(@loteSem);")


        If SQL.RecordCount < 1 Then
            MsgBox("O lote de sementes selecionado ainda não originou o respetivo Produto Final")
            Exit Sub
        End If

        For Each r As DataRow In SQL.DBT.Rows
            txtPeso.Text = r("peso")
            txtTempo.Text = r("tempo_durabilidade")
            txtEspecie.Text = r("especie")
            txtPreco.Text = r("preco")
            txtFuncNIF.Text = r("Func_nif")
            txtCoopNIF.Text = r("CooperativaNif")
            txtLotePF.Text = r("nu_loteProdFinal")
        Next

        LoadGrid(txtCoopNIF.Text)

    End Sub


    Private Sub cbxSeeds_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxSeeds.SelectedIndexChanged
        GetFinalProdDetails(cbxSeeds.Text)
    End Sub

    Private Sub LoadGrid(CooperativaNIF As Integer)

        SQL.AddParam("@coopNIF", CooperativaNIF)
        SQL.ExeQuery("Select * From dbo.getCooperativa(@coopNIF);")

        ' ERROR HANDLING
        If SQL.HasException(True) Then
            MsgBox("Cooperativa associada ao escoamento do produto não encontrada")
            Exit Sub
        End If

        dgv.DataSource = SQL.DBT


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        PFinalInfo.Show()
    End Sub


End Class


