﻿



Public Class InsertFornecedor

    Private SQL As New SqlControl

    Private Sub InsertFornecedor()
        'ADD SQL PARAMS AND RUN THE COMMAND 

        SQL.AddParam("@NIF", txtNIF.Text)
        SQL.AddParam("@tipoDeFornecedor", txtTipo.Text)


        SQL.ExeQuery("EXEC NewFornecedor @nif=@NIF, @tipo=@tipoDeFornecedor;")


        ' REPORT & ABORT ON ERRORS

        If SQL.HasException(True) Then Exit Sub

        MsgBox("Fornecedor adicionado com sucesso !")

        If SQL.DBT.Rows.Count > 0 Then
            Dim r As DataRow = SQL.DBT.Rows(0)
            'MsgBox(r("LastID").ToString)
        End If

        Me.Hide()

    End Sub





    Private Sub txtNIF_TextChanged(sender As Object, e As EventArgs) Handles txtNIF.TextChanged, txtTipo.TextChanged
        cmdAdd.Enabled = True
    End Sub

    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        InsertFornecedor()
    End Sub


End Class