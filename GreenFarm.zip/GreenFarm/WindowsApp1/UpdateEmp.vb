﻿Public Class UpdateEmp

    Private SQL As New SqlControl

    Private Sub FetchEmps()
        ' REFRESH Employees LIST
        lbEmps.Items.Clear()

        ' ADD PARAMS & RUN QUERY
        SQL.AddParam("@nif", "%" & txtFilter.Text & "%")


        SQL.ExeQuery("SearchFuncByNIF @item = @nif")
        'REPORT AND ABORT ON ERRORS

        If SQL.HasException(True) Then Exit Sub

        'LOOP ROWS AND RETURN EQUIPAMENTOS TO LIST

        For Each r As DataRow In SQL.DBT.Rows
            lbEmps.Items.Add(r("nif"))
        Next

    End Sub


    Private Sub UpdateEmp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FetchEmps()
    End Sub


    Private Sub GetEmployeesDetails(NIF As Integer)
        SQL.AddParam("@nif", NIF)
        SQL.ExeQuery("SearchFuncByNIF @item = @nif;")

        If SQL.RecordCount < 1 Then Exit Sub

        For Each r As DataRow In SQL.DBT.Rows
            txtNIF.Text = r("nif")
            txtNome.Text = r("nome")
            txtTipoContrato.Text = r("tipo_contrato")
            txtSalario.Text = r("salario")
            txtTipoTrabalho.Text = r("tipo_de_trabalho")
            txtHoras.Text = r("horas_semanais")
        Next

    End Sub


    Private Sub UpdateEmps()
        SQL.AddParam("@nif", txtNIF.Text)
        SQL.AddParam("@nome", txtNome.Text)
        SQL.AddParam("@tipoContrato", txtTipoContrato.Text)
        SQL.AddParam("@salario", txtSalario.Text)
        SQL.AddParam("@tipoTrabalho", txtTipoTrabalho.Text)
        SQL.AddParam("@horas", txtHoras.Text)


        SQL.ExeQuery("UPDATE Funcionario SET nome=@nome, tipo_contrato=@tipoContrato, salario=@salario, tipo_de_trabalho=@tipoTrabalho, horas_semanais=@horas WHERE nif=@nif;")

        If SQL.HasException(True) Then Exit Sub

        MsgBox("A informação relativa ao empregado selecionado foi atualizada !")


    End Sub


    Private Sub txtFilter_KeyDown(sender As Object, e As KeyEventArgs) Handles txtFilter.KeyDown
        If e.KeyCode = Keys.Enter Then
            FetchEmps()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub




    Private Sub lbEmps_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbEmps.SelectedIndexChanged
        GetEmployeesDetails(lbEmps.Text)
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        UpdateEmps()
    End Sub
End Class