﻿Public Class RemoveSupplier
    Private SQL As New SqlControl

    Private Sub FetchFornecedores()
        'REFRESH EQUIPMENT LIST
        clbEmps.Items.Clear()

        'ADD PARAMS AND RUN QUERY
        Sql.AddParam("@nif", "%" & txtFilter.Text & "%")

        SQL.ExeQuery("Select FORNnif FROM Fornecedor WHERE FORNnif LIKE @nif;")

        ' LOOP ROWS AND RETURN EQUIPAMENTOS TO THE LIST
        For Each r As DataRow In Sql.DBT.Rows
            clbEmps.Items.Add(r("FORNnif"))
        Next

    End Sub

    Private Sub RemoveSupplier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FetchFornecedores()
    End Sub


    Private Sub DeleteFornecedores()
        If MsgBox("Os Fornecedores selecionados serão removidos! Deseja continuar a operação?", MsgBoxStyle.YesNo, "Remover Fornecedor(es) ?") = MsgBoxResult.Yes Then
            'GENERATE MASS DELETE COMMAND
            Dim c As Integer 'unique ID for auto generated numbers
            Dim DelString As String = "" ' query string builder

            For Each i As String In clbEmps.CheckedItems
                SQL.AddParam("@nif" & c, i)
                DelString += "DELETE FROM Fornecedor WHERE FORNnif=@nif" & c & ";"
                c += 1
            Next

            SQL.ExeQuery(DelString)

            If SQL.HasException(True) Then Exit Sub

            MsgBox("Os Fornecedores selecionados foram removidos!")

            'REFRESH LISTA DE EQUIPAMENTOS

            FetchFornecedores()

        End If
    End Sub

    Private Sub txtFilter_KeyDown(sender As Object, e As KeyEventArgs) Handles txtFilter.KeyDown
        If e.KeyCode = Keys.Enter Then
            FetchFornecedores()
            e.Handled() = True
            e.SuppressKeyPress = True  'suppress barulho
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If clbEmps.CheckedItems.Count > 0 Then DeleteFornecedores()
    End Sub
End Class