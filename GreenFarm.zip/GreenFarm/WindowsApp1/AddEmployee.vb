﻿Public Class AddEmployee

    Private SQL As New SqlControl



    Private Sub InsertEmployee()
        'ADD SQL PARAMS AND RUN THE COMMAND 

        SQL.AddParam("@NIF", txtNIF.Text)
        SQL.AddParam("@name", txtNome.Text)
        SQL.AddParam("@tipo_trabalho", txtTipoTrabalho.Text)
        SQL.AddParam("@tipo_contrato", txtTipoContrato.Text)
        SQL.AddParam("@salary", txtSalario.Text)
        SQL.AddParam("@horasSemanais", txtHoras.Text)


        SQL.ExeQuery("EXEC NewFunc @nome = @name,@nif = @NIF,@tipoTrabalho = @tipo_trabalho,@tipoContrato = @tipo_contrato,@salario= @salary,@horas=@horasSemanais;")


        ' REPORT & ABORT ON ERRORS

        If SQL.HasException(True) Then Exit Sub

        MsgBox("Empregado registado com sucesso !")

        If SQL.DBT.Rows.Count > 0 Then
            Dim r As DataRow = SQL.DBT.Rows(0)
            'MsgBox(r("LastID").ToString)
        End If

        Me.Hide()

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        InsertEmployee()
    End Sub


    Private Sub txtNIF_TextChanged(sender As Object, e As EventArgs) Handles txtNIF.TextChanged, txtNome.TextChanged, txtTipoTrabalho.TextChanged, txtTipoTrabalho.TextChanged, txtTipoContrato.TextChanged, txtHoras.TextChanged

        'BASIC VALIDATION
        If Not String.IsNullOrWhiteSpace(txtNIF.Text) AndAlso Not String.IsNullOrWhiteSpace(txtNome.Text) AndAlso Not String.IsNullOrWhiteSpace(txtTipoTrabalho.Text) AndAlso Not String.IsNullOrWhiteSpace(txtTipoContrato.Text) AndAlso Not String.IsNullOrWhiteSpace(txtSalario.Text) AndAlso Not String.IsNullOrWhiteSpace(txtHoras.Text) Then
            btnAdd.Enabled = True
        End If

    End Sub


End Class