﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UpdateEmp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtFilter = New System.Windows.Forms.TextBox()
        Me.lbEmps = New System.Windows.Forms.ListBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.txtHoras = New System.Windows.Forms.TextBox()
        Me.txtSalario = New System.Windows.Forms.TextBox()
        Me.txtTipoTrabalho = New System.Windows.Forms.TextBox()
        Me.txtTipoContrato = New System.Windows.Forms.TextBox()
        Me.txtNome = New System.Windows.Forms.TextBox()
        Me.txtNIF = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(218, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pesquisar empregados pelo NIF :"
        '
        'txtFilter
        '
        Me.txtFilter.Location = New System.Drawing.Point(30, 61)
        Me.txtFilter.Name = "txtFilter"
        Me.txtFilter.Size = New System.Drawing.Size(242, 22)
        Me.txtFilter.TabIndex = 1
        '
        'lbEmps
        '
        Me.lbEmps.FormattingEnabled = True
        Me.lbEmps.ItemHeight = 16
        Me.lbEmps.Location = New System.Drawing.Point(30, 110)
        Me.lbEmps.Name = "lbEmps"
        Me.lbEmps.Size = New System.Drawing.Size(242, 324)
        Me.lbEmps.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnSave)
        Me.GroupBox1.Controls.Add(Me.txtHoras)
        Me.GroupBox1.Controls.Add(Me.txtSalario)
        Me.GroupBox1.Controls.Add(Me.txtTipoTrabalho)
        Me.GroupBox1.Controls.Add(Me.txtTipoContrato)
        Me.GroupBox1.Controls.Add(Me.txtNome)
        Me.GroupBox1.Controls.Add(Me.txtNIF)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(317, 110)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(471, 328)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Dados do Empregado"
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(193, 305)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(156, 23)
        Me.btnSave.TabIndex = 12
        Me.btnSave.Text = "Guardar Alterações"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'txtHoras
        '
        Me.txtHoras.Location = New System.Drawing.Point(193, 251)
        Me.txtHoras.Name = "txtHoras"
        Me.txtHoras.Size = New System.Drawing.Size(208, 22)
        Me.txtHoras.TabIndex = 11
        '
        'txtSalario
        '
        Me.txtSalario.Location = New System.Drawing.Point(193, 210)
        Me.txtSalario.Name = "txtSalario"
        Me.txtSalario.Size = New System.Drawing.Size(208, 22)
        Me.txtSalario.TabIndex = 10
        '
        'txtTipoTrabalho
        '
        Me.txtTipoTrabalho.Location = New System.Drawing.Point(193, 170)
        Me.txtTipoTrabalho.Name = "txtTipoTrabalho"
        Me.txtTipoTrabalho.Size = New System.Drawing.Size(208, 22)
        Me.txtTipoTrabalho.TabIndex = 9
        '
        'txtTipoContrato
        '
        Me.txtTipoContrato.Location = New System.Drawing.Point(193, 126)
        Me.txtTipoContrato.Name = "txtTipoContrato"
        Me.txtTipoContrato.Size = New System.Drawing.Size(208, 22)
        Me.txtTipoContrato.TabIndex = 8
        '
        'txtNome
        '
        Me.txtNome.Location = New System.Drawing.Point(193, 82)
        Me.txtNome.Name = "txtNome"
        Me.txtNome.Size = New System.Drawing.Size(208, 22)
        Me.txtNome.TabIndex = 7
        '
        'txtNIF
        '
        Me.txtNIF.Enabled = False
        Me.txtNIF.Location = New System.Drawing.Point(193, 33)
        Me.txtNIF.Name = "txtNIF"
        Me.txtNIF.Size = New System.Drawing.Size(208, 22)
        Me.txtNIF.TabIndex = 6
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(16, 251)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(120, 17)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "Horas Semanais :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(76, 210)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 17)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Salario :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(11, 170)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(125, 17)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Tipo de Trabalho :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(122, 17)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Tipo de Contrato :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(83, 82)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 17)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Nome :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(99, 33)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 17)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "NIF :"
        '
        'UpdateEmp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lbEmps)
        Me.Controls.Add(Me.txtFilter)
        Me.Controls.Add(Me.Label1)
        Me.Name = "UpdateEmp"
        Me.Text = "UpdateEmp"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtFilter As TextBox
    Friend WithEvents lbEmps As ListBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtNIF As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnSave As Button
    Friend WithEvents txtHoras As TextBox
    Friend WithEvents txtSalario As TextBox
    Friend WithEvents txtTipoTrabalho As TextBox
    Friend WithEvents txtTipoContrato As TextBox
    Friend WithEvents txtNome As TextBox
End Class
