﻿Public Class RemEmployees

    Private SQL As New SqlControl

    Private Sub RemEmployees_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FetchEmployees()
    End Sub

    Private Sub FetchEmployees()
        'REFRESH EQUIPMENT LIST
        clbEmps.Items.Clear()

        'ADD PARAMS AND RUN QUERY
        SQL.AddParam("@nif", "%" & txtFilter.Text & "%")

        SQL.ExeQuery("SearchFuncByNIF @item = @nif;")

        ' LOOP ROWS AND RETURN EQUIPAMENTOS TO THE LIST
        For Each r As DataRow In SQL.DBT.Rows
            clbEmps.Items.Add(r("nif"))
        Next

    End Sub


    Private Sub DeleteEmployees()
        If MsgBox("Os empregados selecionados serão removidos! Deseja continuar a operação?", MsgBoxStyle.YesNo, "Remover Empregados(s) ?") = MsgBoxResult.Yes Then
            'GENERATE MASS DELETE COMMAND
            Dim c As Integer 'unique ID for auto generated numbers
            Dim DelString As String = "" ' query string builder

            For Each i As String In clbEmps.CheckedItems
                SQL.AddParam("@nif" & c, i)
                DelString += "DELETE FROM Funcionario WHERE nif=@nif" & c & ";"
                c += 1
            Next

            SQL.ExeQuery(DelString)

            If SQL.HasException(True) Then Exit Sub

            MsgBox("Os empregados selecionados foram removidos!")

            'REFRESH LISTA DE EQUIPAMENTOS

            FetchEmployees()

        End If
    End Sub



    Private Sub txtFilter_KeyDown(sender As Object, e As KeyEventArgs) Handles txtFilter.KeyDown
        If e.KeyCode = Keys.Enter Then
            FetchEmployees()
            e.Handled() = True
            e.SuppressKeyPress = True  'suppress barulho
        End If
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If clbEmps.CheckedItems.Count > 0 Then DeleteEmployees()
    End Sub


End Class