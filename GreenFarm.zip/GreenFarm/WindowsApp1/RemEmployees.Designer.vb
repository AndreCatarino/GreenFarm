﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RemEmployees
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.clbEmps = New System.Windows.Forms.CheckedListBox()
        Me.txtFilter = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(47, 431)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(237, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Remover Empregado(s)"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'clbEmps
        '
        Me.clbEmps.FormattingEnabled = True
        Me.clbEmps.Location = New System.Drawing.Point(47, 102)
        Me.clbEmps.Name = "clbEmps"
        Me.clbEmps.Size = New System.Drawing.Size(237, 310)
        Me.clbEmps.TabIndex = 1
        '
        'txtFilter
        '
        Me.txtFilter.Location = New System.Drawing.Point(47, 46)
        Me.txtFilter.Name = "txtFilter"
        Me.txtFilter.Size = New System.Drawing.Size(237, 22)
        Me.txtFilter.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(44, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(211, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Procurar Empregados pelo NIF :"
        '
        'RemEmployees
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(371, 482)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtFilter)
        Me.Controls.Add(Me.clbEmps)
        Me.Controls.Add(Me.Button1)
        Me.Name = "RemEmployees"
        Me.Text = "RemEmployees"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents clbEmps As CheckedListBox
    Friend WithEvents txtFilter As TextBox
    Friend WithEvents Label1 As Label
End Class
