﻿Public Class addManutencao

    Private SQL As SqlControl


    Private Sub addManutencao()

        'ADD SQL PARAMS AND RUN THE COMMAND 

        SQL.AddParam("@IDman", txtIDmanEquip.Text)
        SQL.AddParam("@SerialNumber", txtNuSerie.Text)

        SQL.ExeQuery("EXEC INSERTequipMan @nu_serie=@SerialNumber,@ID=@IDman;")

        If SQL.HasException(True) Then Exit Sub

        MsgBox("Equipamento foi enviado para a manutenção com sucesso !")

        Me.Hide()
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles addMan.Click
        addManutencao()
        addMan.Enabled = False
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        GerirEquipamentos.Show()
    End Sub

    Private Sub addManutencao_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class