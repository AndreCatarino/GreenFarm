﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DelEquip
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtFilter = New System.Windows.Forms.TextBox()
        Me.clbEquip = New System.Windows.Forms.CheckedListBox()
        Me.cmdDel = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtFilter
        '
        Me.txtFilter.Location = New System.Drawing.Point(21, 54)
        Me.txtFilter.Name = "txtFilter"
        Me.txtFilter.Size = New System.Drawing.Size(281, 22)
        Me.txtFilter.TabIndex = 0
        '
        'clbEquip
        '
        Me.clbEquip.FormattingEnabled = True
        Me.clbEquip.Location = New System.Drawing.Point(21, 96)
        Me.clbEquip.Name = "clbEquip"
        Me.clbEquip.Size = New System.Drawing.Size(281, 327)
        Me.clbEquip.TabIndex = 1
        '
        'cmdDel
        '
        Me.cmdDel.Location = New System.Drawing.Point(21, 447)
        Me.cmdDel.Name = "cmdDel"
        Me.cmdDel.Size = New System.Drawing.Size(281, 23)
        Me.cmdDel.TabIndex = 2
        Me.cmdDel.Text = "Delete"
        Me.cmdDel.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(2, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(391, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Pesquisar pelo número de série do equipamento a remover :"
        '
        'DelEquip
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(401, 500)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmdDel)
        Me.Controls.Add(Me.clbEquip)
        Me.Controls.Add(Me.txtFilter)
        Me.Name = "DelEquip"
        Me.Text = "Remover Equipamentos"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtFilter As TextBox
    Friend WithEvents clbEquip As CheckedListBox
    Friend WithEvents cmdDel As Button
    Friend WithEvents Label1 As Label
End Class
