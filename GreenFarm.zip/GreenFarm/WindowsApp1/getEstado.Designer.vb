﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class getEstado
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbxNuserie = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtPeso = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt = New System.Windows.Forms.TextBox()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtNuSerie = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtIDmanEquip = New System.Windows.Forms.TextBox()
        Me.addMan = New System.Windows.Forms.Button()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.txtDate = New System.Windows.Forms.TextBox()
        Me.txtTipo = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(47, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(303, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Selecione o número de série do equipamento :"
        '
        'cbxNuserie
        '
        Me.cbxNuserie.FormattingEnabled = True
        Me.cbxNuserie.Location = New System.Drawing.Point(50, 90)
        Me.cbxNuserie.Name = "cbxNuserie"
        Me.cbxNuserie.Size = New System.Drawing.Size(313, 24)
        Me.cbxNuserie.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(40, 185)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Estado :"
        '
        'txtPeso
        '
        Me.txtPeso.Location = New System.Drawing.Point(43, 221)
        Me.txtPeso.Name = "txtPeso"
        Me.txtPeso.Size = New System.Drawing.Size(246, 22)
        Me.txtPeso.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(40, 288)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(196, 17)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Data do ínicio da Manutenção"
        '
        'txt
        '
        Me.txt.Location = New System.Drawing.Point(43, 334)
        Me.txt.Name = "txt"
        Me.txt.Size = New System.Drawing.Size(246, 22)
        Me.txt.TabIndex = 9
        '
        'dgv
        '
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(618, 130)
        Me.dgv.Name = "dgv"
        Me.dgv.RowTemplate.Height = 24
        Me.dgv.Size = New System.Drawing.Size(336, 285)
        Me.dgv.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(615, 97)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(211, 17)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Equipamentos em Manutenção :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(40, 455)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(269, 17)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Adicionar Equipamento para manutencao"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(92, 523)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(224, 17)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Número de série de Equipamento:"
        '
        'txtNuSerie
        '
        Me.txtNuSerie.Location = New System.Drawing.Point(322, 520)
        Me.txtNuSerie.Name = "txtNuSerie"
        Me.txtNuSerie.Size = New System.Drawing.Size(214, 22)
        Me.txtNuSerie.TabIndex = 14
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 572)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(304, 17)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "ID associado ao equipamento em manutenção:"
        '
        'txtIDmanEquip
        '
        Me.txtIDmanEquip.Location = New System.Drawing.Point(322, 569)
        Me.txtIDmanEquip.Name = "txtIDmanEquip"
        Me.txtIDmanEquip.Size = New System.Drawing.Size(214, 22)
        Me.txtIDmanEquip.TabIndex = 16
        '
        'addMan
        '
        Me.addMan.AccessibleDescription = ""
        Me.addMan.Location = New System.Drawing.Point(516, 634)
        Me.addMan.Name = "addMan"
        Me.addMan.Size = New System.Drawing.Size(214, 23)
        Me.addMan.TabIndex = 17
        Me.addMan.Text = "Adicionar para Manutenção"
        Me.addMan.UseVisualStyleBackColor = True
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(611, 569)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(119, 22)
        Me.txtState.TabIndex = 19
        '
        'txtDate
        '
        Me.txtDate.Location = New System.Drawing.Point(611, 522)
        Me.txtDate.Name = "txtDate"
        Me.txtDate.Size = New System.Drawing.Size(119, 22)
        Me.txtDate.TabIndex = 20
        '
        'txtTipo
        '
        Me.txtTipo.Location = New System.Drawing.Point(865, 537)
        Me.txtTipo.Name = "txtTipo"
        Me.txtTipo.Size = New System.Drawing.Size(120, 22)
        Me.txtTipo.TabIndex = 21
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(542, 525)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(64, 17)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "joinDate:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(551, 569)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 17)
        Me.Label9.TabIndex = 23
        Me.Label9.Text = "estado:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(741, 540)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 17)
        Me.Label10.TabIndex = 24
        Me.Label10.Text = "tipo Manutencao:"
        '
        'getEstado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(997, 669)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtTipo)
        Me.Controls.Add(Me.txtDate)
        Me.Controls.Add(Me.txtState)
        Me.Controls.Add(Me.addMan)
        Me.Controls.Add(Me.txtIDmanEquip)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtNuSerie)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.txt)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtPeso)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cbxNuserie)
        Me.Controls.Add(Me.Label1)
        Me.Name = "getEstado"
        Me.Text = "getEstado"
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents cbxNuserie As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtPeso As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txt As TextBox
    Friend WithEvents dgv As DataGridView
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtNuSerie As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtIDmanEquip As TextBox
    Friend WithEvents addMan As Button
    Friend WithEvents txtState As TextBox
    Friend WithEvents txtDate As TextBox
    Friend WithEvents txtTipo As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
End Class
