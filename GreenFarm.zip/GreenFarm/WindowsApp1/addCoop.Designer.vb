﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class addCoop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtNIF = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtCotas = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtFundos = New System.Windows.Forms.TextBox()
        Me.txtNome = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.adicionarCoop = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 107)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(137, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "NIF  da Cooperativa:"
        '
        'txtNIF
        '
        Me.txtNIF.Location = New System.Drawing.Point(158, 107)
        Me.txtNIF.Name = "txtNIF"
        Me.txtNIF.Size = New System.Drawing.Size(234, 22)
        Me.txtNIF.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(48, 163)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 17)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Cotas Mensais:"
        '
        'txtCotas
        '
        Me.txtCotas.Location = New System.Drawing.Point(158, 158)
        Me.txtCotas.Name = "txtCotas"
        Me.txtCotas.Size = New System.Drawing.Size(234, 22)
        Me.txtCotas.TabIndex = 9
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(93, 226)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 17)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Fundos:"
        '
        'txtFundos
        '
        Me.txtFundos.Location = New System.Drawing.Point(158, 223)
        Me.txtFundos.Name = "txtFundos"
        Me.txtFundos.Size = New System.Drawing.Size(234, 22)
        Me.txtFundos.TabIndex = 11
        '
        'txtNome
        '
        Me.txtNome.Location = New System.Drawing.Point(158, 285)
        Me.txtNome.Name = "txtNome"
        Me.txtNome.Size = New System.Drawing.Size(234, 22)
        Me.txtNome.TabIndex = 12
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 288)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(149, 17)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Nome da Cooperativa:"
        '
        'adicionarCoop
        '
        Me.adicionarCoop.Location = New System.Drawing.Point(158, 392)
        Me.adicionarCoop.Name = "adicionarCoop"
        Me.adicionarCoop.Size = New System.Drawing.Size(163, 23)
        Me.adicionarCoop.TabIndex = 14
        Me.adicionarCoop.Text = "Adicionar Cooperativa"
        Me.adicionarCoop.UseVisualStyleBackColor = True
        '
        'addCoop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(493, 445)
        Me.Controls.Add(Me.adicionarCoop)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtNome)
        Me.Controls.Add(Me.txtFundos)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtCotas)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtNIF)
        Me.Controls.Add(Me.Label1)
        Me.Name = "addCoop"
        Me.Text = "addCoop"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtNIF As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtCotas As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtFundos As TextBox
    Friend WithEvents txtNome As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents adicionarCoop As Button
End Class
