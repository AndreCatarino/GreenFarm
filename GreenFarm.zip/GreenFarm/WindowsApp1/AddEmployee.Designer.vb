﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtNIF = New System.Windows.Forms.TextBox()
        Me.txtNome = New System.Windows.Forms.TextBox()
        Me.txtTipoTrabalho = New System.Windows.Forms.TextBox()
        Me.txtTipoContrato = New System.Windows.Forms.TextBox()
        Me.txtSalario = New System.Windows.Forms.TextBox()
        Me.txtHoras = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(154, 74)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "NIF :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(138, 125)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nome :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(66, 178)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(125, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Tipo de Trabalho :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(69, 224)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(122, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Tipo de Contrato :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(131, 284)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Salário :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(71, 336)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(120, 17)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Horas Semanais :"
        '
        'txtNIF
        '
        Me.txtNIF.Location = New System.Drawing.Point(226, 74)
        Me.txtNIF.Name = "txtNIF"
        Me.txtNIF.Size = New System.Drawing.Size(234, 22)
        Me.txtNIF.TabIndex = 6
        '
        'txtNome
        '
        Me.txtNome.Location = New System.Drawing.Point(226, 119)
        Me.txtNome.Name = "txtNome"
        Me.txtNome.Size = New System.Drawing.Size(234, 22)
        Me.txtNome.TabIndex = 7
        '
        'txtTipoTrabalho
        '
        Me.txtTipoTrabalho.Location = New System.Drawing.Point(226, 178)
        Me.txtTipoTrabalho.Name = "txtTipoTrabalho"
        Me.txtTipoTrabalho.Size = New System.Drawing.Size(234, 22)
        Me.txtTipoTrabalho.TabIndex = 8
        '
        'txtTipoContrato
        '
        Me.txtTipoContrato.Location = New System.Drawing.Point(226, 224)
        Me.txtTipoContrato.Name = "txtTipoContrato"
        Me.txtTipoContrato.Size = New System.Drawing.Size(234, 22)
        Me.txtTipoContrato.TabIndex = 9
        '
        'txtSalario
        '
        Me.txtSalario.Location = New System.Drawing.Point(226, 279)
        Me.txtSalario.Name = "txtSalario"
        Me.txtSalario.Size = New System.Drawing.Size(234, 22)
        Me.txtSalario.TabIndex = 10
        '
        'txtHoras
        '
        Me.txtHoras.Location = New System.Drawing.Point(226, 336)
        Me.txtHoras.Name = "txtHoras"
        Me.txtHoras.Size = New System.Drawing.Size(234, 22)
        Me.txtHoras.TabIndex = 11
        '
        'btnAdd
        '
        Me.btnAdd.Enabled = False
        Me.btnAdd.Location = New System.Drawing.Point(226, 415)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(197, 23)
        Me.btnAdd.TabIndex = 12
        Me.btnAdd.Text = "Registar Empregado"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'AddEmployee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(629, 473)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.txtHoras)
        Me.Controls.Add(Me.txtSalario)
        Me.Controls.Add(Me.txtTipoContrato)
        Me.Controls.Add(Me.txtTipoTrabalho)
        Me.Controls.Add(Me.txtNome)
        Me.Controls.Add(Me.txtNIF)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "AddEmployee"
        Me.Text = "AddEmployee"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtNIF As TextBox
    Friend WithEvents txtNome As TextBox
    Friend WithEvents txtTipoTrabalho As TextBox
    Friend WithEvents txtTipoContrato As TextBox
    Friend WithEvents txtSalario As TextBox
    Friend WithEvents txtHoras As TextBox
    Friend WithEvents btnAdd As Button
End Class
