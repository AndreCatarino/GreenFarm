﻿Imports System.Data.SqlClient

Public Class SqlControl

    Private DBcon As New SqlConnection("Data Source = tcp:mednat.ieeta.pt\SQLSERVER,8101;  initial catalog = p7g8; uid = p7g8; password = bd_2019g8")
    Private DBcmd As New SqlCommand

    'DB data

    Public DBDA As SqlDataAdapter
    Public DBT As DataTable


    ' QUERY PARAMETERS

    Public Params As New List(Of SqlParameter)

    'Query Statistics

    Public RecordCount As Integer
    Public Exception As String

    Public Sub New()

    End Sub

    ' ALLOW CONNECTION STRING OVERRIDE

    Public Sub New(ConnectionString As String)
        DBcon = New SqlConnection(ConnectionString)
    End Sub

    'EXECUTE QUERY SUB

    Public Sub ExeQuery(query As String, Optional ReturnIdentity As Boolean = False)
        ' RESET QUERY STATS
        RecordCount = 0
        Exception = ""

        Try
            DBcon.Open()

            ' CREATE DB COMMAND

            DBcmd = New SqlCommand(query, DBcon)

            ' LOAD PARAMS INTO DB COMMAND

            Params.ForEach(Sub(p) DBcmd.Parameters.Add(p))

            ' CLEAR PARAM LIST

            Params.Clear()

            ' EXECUTE THE COMMAND AND FILL DATASET

            DBT = New DataTable
            DBDA = New SqlDataAdapter(DBcmd)
            RecordCount = DBDA.Fill(DBT)

            If ReturnIdentity = True Then  ' good for multi user environment

                Dim ReturnQuery As String = "Select @@IDENTITY as LastID;"
                '@@Identity - session
                DBcmd = New SqlCommand(ReturnQuery, DBcon)
                DBT = New DataTable
                DBDA = New SqlDataAdapter(DBcmd)
                RecordCount = DBDA.Fill(DBT)
            End If


        Catch ex As Exception
            ' CAPTURE ERROR
            Exception = "ExecQuery Error: " & vbNewLine & ex.Message

        Finally
            'CLOSE CONNECTION
            If DBcon.State = ConnectionState.Open Then DBcon.Close()
        End Try
    End Sub


    ' ADD PARAMS

    Public Sub AddParam(Name As String, Value As Object)

        Dim newParam As New SqlParameter(Name, Value)
        Params.Add(newParam)

    End Sub

    ' ERROR CHECKING

    Public Function HasException(Optional Report As Boolean = False) As Boolean
        If String.IsNullOrEmpty(Exception) Then Return False
        If Report = True Then MsgBox(Exception, MsgBoxStyle.Critical, "Exception:")
        Return True
    End Function


End Class
